<!doctype html>
<html lang="id" data-tema="hijau">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Kasir Servis Pro - ADOB CELL</title>
<meta name="theme-color" content="#EBEFEA">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" href="icon-192.png">
<link rel="apple-touch-icon" href="icon-192.png">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wght@600;700;800&family=Fraunces:opsz,wght@9..144,600;9..144,800&family=IBM+Plex+Mono:wght@400;500;700&family=IBM+Plex+Sans:wght@400;500;600;700&family=Sora:wght@600;700;800&display=swap">
<style>
:root,[data-tema=hijau]{--bg:#EBEFEA;--surface:#fff;--surface2:#F4F7F3;--fg:#16211D;--muted:#586861;--line:#D3DBD4;--accent:#0B7A5A;--accent-fg:#fff;--accent-soft:#D6EEE4;--good:#1B7F4B;--warn:#9A5B00;--bad:#B3261E;--good-soft:#D8EFDF;--warn-soft:#F8E9CC;--bad-soft:#F7DEDB;--r:8px;--rs:6px;--bw:1px;--f-d:'Archivo',system-ui,sans-serif;--f-b:'IBM Plex Sans',system-ui,sans-serif;--f-m:'IBM Plex Mono',ui-monospace,monospace}
[data-tema=malam]{--bg:#0F1613;--surface:#17211D;--surface2:#1D2924;--fg:#E6EEE9;--muted:#97A99F;--line:#2B3B34;--accent:#3DD6A3;--accent-fg:#04281C;--accent-soft:#12372B;--good:#4CCB8B;--warn:#E3A53B;--bad:#F28B82;--good-soft:#13341F;--warn-soft:#3A2D12;--bad-soft:#3D1F1D;color-scheme:dark}
[data-tema=samudra]{--bg:#E7EEF7;--surface:#fff;--surface2:#F1F6FC;--fg:#0F2036;--muted:#53657B;--line:#CBD8E6;--accent:#0A5FD0;--accent-fg:#fff;--accent-soft:#D9E8FB;--good:#17753F;--warn:#935300;--good-soft:#D6EFDD;--warn-soft:#F7E7C8;--r:12px;--rs:8px;--f-d:'Sora',system-ui,sans-serif}
[data-tema=senja]{--bg:#0D1322;--surface:#151D33;--surface2:#1B2540;--fg:#E9EDF8;--muted:#9AA6C4;--line:#2A3658;--accent:#F2B544;--accent-fg:#1A1200;--accent-soft:#3A2F12;--good:#5BD49A;--warn:#F2B544;--bad:#FF8A80;--good-soft:#12362A;--warn-soft:#3A2F12;--bad-soft:#40201F;--r:10px;--rs:7px;color-scheme:dark}
[data-tema=mawar]{--bg:#F3ECF0;--surface:#fff;--surface2:#FAF5F8;--fg:#2A1420;--muted:#6B5260;--line:#E2D2DB;--accent:#B01E5B;--accent-fg:#fff;--accent-soft:#F6D9E6;--good:#17753F;--warn:#935300;--good-soft:#D6EFDD;--warn-soft:#F7E7C8;--r:16px;--rs:10px;--f-d:'Fraunces',Georgia,serif}
[data-tema=kontras]{--bg:#fff;--surface:#fff;--surface2:#F0F0F0;--fg:#000;--muted:#2B2B2B;--line:#000;--accent:#000;--accent-fg:#fff;--accent-soft:#FFE600;--good:#006400;--warn:#7A4A00;--bad:#B00020;--good-soft:#CFF5CF;--warn-soft:#FFE9A8;--bad-soft:#FFD0D6;--r:2px;--rs:2px;--bw:2px;--f-d:'IBM Plex Mono',monospace}
:root{--fs:15px}[data-fs=s]{--fs:14px}[data-fs=l]{--fs:17px}
*{box-sizing:border-box}html{font-size:var(--fs)}html,body{margin:0}
body{background:var(--bg);color:var(--fg);font:1rem/1.5 var(--f-b);padding:0 max(16px,env(safe-area-inset-left,0px));-webkit-text-size-adjust:100%}
.wrap{max-width:880px;margin:0 auto}
h1,h2,h3{font-family:var(--f-d);margin:0;letter-spacing:-.01em}
h1{font-size:1.35rem;font-weight:800;line-height:1.15}h2{font-size:1.13rem;font-weight:700}
h3{font-size:.9rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}
button,input,select,textarea{font:inherit;color:inherit}
:focus-visible{outline:3px solid var(--accent);outline-offset:2px}
.num{font-family:var(--f-m);font-variant-numeric:tabular-nums;white-space:nowrap}
.top{position:sticky;top:0;z-index:5;background:var(--bg);display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:8px 16px;padding:12px 0;border-bottom:var(--bw) solid var(--line)}
.sub{display:block;font-size:.8rem;color:var(--muted);background:none;border:0;padding:0;text-align:left;cursor:pointer}
.sub .dot{display:inline-block;width:.55em;height:.55em;border-radius:50%;margin-right:.4em;background:var(--muted)}
.sub.ok .dot{background:var(--good)}.sub.wait .dot{background:var(--warn)}.sub.err .dot{background:var(--bad)}
.mon{display:flex;align-items:center;gap:4px;font-family:var(--f-d);font-weight:700}
.mon strong{min-width:7.5rem;text-align:center}
.mon button{width:2.4rem;height:2.4rem;border:var(--bw) solid var(--line);background:var(--surface);border-radius:var(--rs);cursor:pointer;font-size:1.2rem}
main{padding:16px 0 104px;display:grid;gap:16px}
.card{background:var(--surface);border:var(--bw) solid var(--line);border-radius:var(--r);padding:16px;min-width:0}
.stack{display:grid;gap:12px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,200px),1fr));gap:12px}
.row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.row.sb{justify-content:space-between}
.muted{color:var(--muted)}.small{font-size:.87rem}
.sect{font-family:var(--f-d);font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--accent);border-bottom:var(--bw) solid var(--line);padding-bottom:4px}
label.f{display:grid;gap:4px;font-size:.78rem;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.05em;min-width:0}
input,select,textarea{width:100%;min-width:0;padding:.6rem .65rem;border:var(--bw) solid var(--line);border-radius:var(--rs);background:var(--surface2);font-size:max(16px,1rem);font-weight:400}
input[type=checkbox]{width:auto}
textarea{resize:vertical;min-height:4.5rem}
input:focus,select:focus,textarea:focus{border-color:var(--accent)}
.moneyin{display:flex;align-items:center;border:var(--bw) solid var(--line);border-radius:var(--rs);background:var(--surface2);padding-left:.6rem;overflow:hidden}
.moneyin>b{font-size:.87rem;font-weight:800;color:var(--muted);padding-right:.35rem}
.moneyin>input{border:0;background:transparent;padding-left:0;font-family:var(--f-m);font-weight:700}
.moneyin:focus-within{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent)}
.btn{border:var(--bw) solid var(--line);background:var(--surface);padding:.6rem .9rem;border-radius:var(--rs);font-weight:600;cursor:pointer;font-size:.93rem}
.btn:hover{border-color:var(--accent)}
.btn.pri{background:var(--accent);color:var(--accent-fg);border-color:var(--accent)}
.btn.sm{padding:.4rem .7rem;font-size:.87rem}
.btn.danger{color:var(--bad);border-color:var(--bad)}
.btn.armed{background:var(--bad);color:#fff;border-color:var(--bad)}
a.btn{text-decoration:none;display:inline-block}
.seg{display:flex;border:var(--bw) solid var(--line);border-radius:var(--rs);overflow:hidden}
.seg button{flex:1;border:0;background:var(--surface2);padding:.6rem .4rem;cursor:pointer;font-weight:600;border-right:var(--bw) solid var(--line)}
.seg button:last-child{border-right:0}
.seg button[aria-pressed=true]{background:var(--accent);color:var(--accent-fg)}
.chips{display:flex;flex-wrap:wrap;gap:6px}
.chip{padding:.4rem .7rem;border:var(--bw) solid var(--line);background:var(--surface);border-radius:var(--rs);font-size:.87rem;font-weight:600;cursor:pointer}
.chip[aria-pressed=true]{background:var(--accent);color:var(--accent-fg);border-color:var(--accent)}
.pat{display:grid;grid-template-columns:repeat(3,3.3rem);gap:10px}
.pat button{width:3.3rem;height:3.3rem;border-radius:50%;border:2px solid var(--line);background:var(--surface);font-family:var(--f-m);font-weight:700;cursor:pointer;color:var(--muted)}
.pat button[aria-pressed=true]{background:var(--accent);color:var(--accent-fg);border-color:var(--accent)}
.notaimg{display:block;width:100%;max-width:420px;height:auto;margin:0 auto;border:1px solid #bbb;background:#fff}
.sigbox{border:1px dashed var(--line);border-radius:var(--rs);padding:6px;display:grid;gap:6px}
.sigcanvas{width:100%;height:130px;background:#fff;border:var(--bw) solid var(--line);border-radius:4px;touch-action:none;display:block;cursor:crosshair}
.sigimg{max-width:150px;height:auto;border:1px solid var(--line);background:#fff;border-radius:4px}
.item{border:var(--bw) solid var(--line);border-radius:var(--rs);padding:10px;background:var(--surface2);display:grid;gap:8px}
.item-h{display:flex;justify-content:space-between;align-items:center}
.item-g{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,120px),1fr));gap:8px}
.item-g .f-name{grid-column:1/-1}
.tag{font-size:.73rem;font-weight:700;text-transform:uppercase;padding:2px 8px;border-radius:4px}
.tag.jasa{background:var(--accent-soft);color:var(--accent)}.tag.part{background:var(--warn-soft);color:var(--warn)}
.linkbtn{background:none;border:0;color:var(--muted);cursor:pointer;text-decoration:underline;font-size:.87rem;padding:4px}
.ledger{display:grid;font-size:.93rem}
.ledger .ln{display:flex;justify-content:space-between;gap:12px;padding:7px 0;border-bottom:1px dashed var(--line)}
.ledger .ln>span:first-child{min-width:0;overflow-wrap:anywhere}.ledger .ln>span:last-child{text-align:right}
.ledger .ln.tot{border-bottom:2px solid var(--fg);font-weight:700}
.ledger .ln.sub{color:var(--muted);font-size:.87rem;padding-left:12px}
.pos{color:var(--good)}.neg{color:var(--bad)}
.big{font-family:var(--f-d);font-size:2rem;font-weight:800;line-height:1.1}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(78px,1fr));gap:8px}
.stat{border:var(--bw) solid var(--line);border-radius:var(--rs);padding:10px 4px;text-align:center;background:var(--surface2)}
.stat b{display:block;font-size:1.6rem;font-family:var(--f-d);line-height:1.1}.stat span{font-size:.78rem;color:var(--muted);font-weight:600}
.stat.warn b{color:var(--warn)}.stat.good b{color:var(--good)}.stat.bad b{color:var(--bad)}
.nota{font-family:var(--f-m);font-size:.87rem;white-space:pre;overflow-x:auto;background:var(--surface2);border:1px dashed var(--muted);border-radius:4px;padding:14px;margin:0}
.nota.wrapit{white-space:pre-wrap;overflow-wrap:anywhere;font-family:var(--f-b);font-size:.93rem}
.badge{display:inline-block;padding:2px 9px;border-radius:4px;font-size:.8rem;font-weight:700}
.badge.good{background:var(--good-soft);color:var(--good)}.badge.warn{background:var(--warn-soft);color:var(--warn)}.badge.bad{background:var(--bad-soft);color:var(--bad)}.badge.mute{background:var(--surface2);color:var(--muted);border:1px solid var(--line)}
.bar{height:.55rem;background:var(--surface2);border:var(--bw) solid var(--line);border-radius:4px;overflow:hidden}
.bar>i{display:block;height:100%;background:var(--accent)}.bar.bad>i{background:var(--bad)}
.tx{border-top:var(--bw) solid var(--line);padding:12px 0;display:grid;gap:12px}.tx:first-child{border-top:0;padding-top:0}
.tx.cancelled .tx-title{text-decoration:line-through;color:var(--muted)}
.tx-h{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;cursor:pointer;background:none;border:0;text-align:left;width:100%;padding:0}
.tx-h>span{min-width:0}
.box{border:var(--bw) solid var(--line);border-radius:var(--rs);padding:12px;display:grid;gap:10px;background:var(--surface2)}
.tablewrap{overflow-x:auto}
table{border-collapse:collapse;width:100%;font-size:.88rem}
th,td{padding:7px 8px;text-align:left;border-bottom:var(--bw) solid var(--line)}
th{font-size:.75rem;text-transform:uppercase;color:var(--muted)}td.r,th.r{text-align:right}
tr.totrow td{font-weight:700;border-top:2px solid var(--fg)}
.empty{text-align:center;padding:28px 12px;color:var(--muted);display:grid;gap:12px;justify-items:center}
.empty strong{color:var(--fg);font-family:var(--f-d);font-size:1.13rem}
.thms{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,150px),1fr));gap:10px}
.thm{display:grid;gap:8px;padding:10px;border:2px solid var(--line);border-radius:var(--rs);text-align:left;cursor:pointer;background:var(--surface)}
.thm[aria-pressed=true]{border-color:var(--accent);box-shadow:0 0 0 2px var(--accent)}
.thm .pv{display:grid;gap:6px;padding:10px;border-radius:4px;border:1px solid rgba(128,128,128,.35)}
.thm .pv i{display:block;height:.5rem;border-radius:3px}
.tabs{position:fixed;left:0;right:0;bottom:0;z-index:6;background:var(--surface);border-top:var(--bw) solid var(--line);padding:0 8px env(safe-area-inset-bottom,0px)}
.tabs-in{display:flex}
.tab{flex:1;min-width:0;padding:12px 2px 11px;background:none;border:0;border-top:3px solid transparent;font-weight:600;font-size:.83rem;color:var(--muted);cursor:pointer}
.tab[aria-current=page]{color:var(--accent);border-top-color:var(--accent)}
#toast{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(72px + env(safe-area-inset-bottom,0px));background:var(--fg);color:var(--bg);padding:9px 14px;border-radius:var(--rs);font-size:.93rem;z-index:20;max-width:calc(100vw - 32px);opacity:0;pointer-events:none;transition:opacity .15s}
#toast.on{opacity:1}
@media (min-width:700px){h1{font-size:1.6rem}}
</style>
</head>
<body>
<div id="app"></div>
<div id="toast" role="status" aria-live="polite"></div>
<script>
(function(){
'use strict';
var BULAN=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
var HARI=['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
var CATS=['Sewa tempat','Listrik & air','Internet & pulsa','Alat & perlengkapan','Konsumsi','Pemasaran','Kebersihan & lainnya'];
var ROLE={admin:'Admin Depan (Lv.1)',interface:'Teknisi Interface (Lv.2)',expert:'Teknisi Expert (Lv.3)'};
var STAT=['Diterima','Dikerjakan','Menunggu konfirmasi','Selesai','Diambil'];
var STLBL={'Diterima':'Diterima / Cek','Dikerjakan':'Dikerjakan','Menunggu konfirmasi':'Menunggu konfirmasi','Selesai':'Selesai','Diambil':'Diambil','Dibatalkan':'Dibatalkan'};
var PROSES=['Diterima','Dikerjakan','Menunggu konfirmasi'];
var WARRS=[0,7,14,30,60,90],PAYS=['Tunai','Transfer','QRIS'];
var STMSG={'Diterima':'terima','Dikerjakan':'proses','Menunggu konfirmasi':'konfirmasi','Selesai':'selesai','Diambil':'garansi'};
var MSGS=[['terima','Bukti penerimaan unit'],['proses','Unit sedang dikerjakan'],['konfirmasi','Minta persetujuan biaya'],['selesai','Unit selesai, siap diambil'],['garansi','Info garansi'],['batal','Pemberitahuan pembatalan']];
var CLAIMRES=['Diperbaiki ulang','Komponen diganti','Ditolak (di luar ketentuan garansi)'];
var THEMES=[['hijau','Hijau Bengkel','#EBEFEA','#16211D','#0B7A5A'],['malam','Malam Hijau','#0F1613','#E6EEE9','#3DD6A3'],['samudra','Samudra','#E7EEF7','#0F2036','#0A5FD0'],['senja','Senja','#0D1322','#E9EDF8','#F2B544'],['mawar','Mawar','#F3ECF0','#2A1420','#B01E5B'],['kontras','Kontras Tinggi','#FFFFFF','#000000','#000000']];
var SVC=['000018f0-0000-1000-8000-00805f9b34fb','0000ff00-0000-1000-8000-00805f9b34fb','e7810a71-73ae-499d-8c15-faa9aef0c3f2','49535343-fe7d-4ae5-8fa9-9fafd205e455','0000ffe0-0000-1000-8000-00805f9b34fb','0000fee7-0000-1000-8000-00805f9b34fb','00001101-0000-1000-8000-00805f9b34fb'];
var HEAD={
 tx:['ID','Diperbarui','Dihapus','Tanggal','No Nota','Pelanggan','No HP','Perangkat','IMEI/SN','Keluhan','Teknisi','Status','Bayar','Rincian','Jasa','Sparepart','Modal Sparepart','Total','Komisi Teknisi','Bonus Admin','Bagian Toko','Garansi (hari)','Garansi Sampai','Jumlah Klaim','DataJSON'],
 exp:['ID','Diperbarui','Dihapus','Tanggal','Kategori','Keterangan','Jumlah','DataJSON'],
 cfg:['ID','Diperbarui','Dihapus','Nama','DataJSON']};

function defaultCfg(){return{id:'main',shop:'ADOB CELL',addr:'',phone:'',warrantyDays:30,
 terms:'Garansi tidak berlaku untuk kerusakan akibat terjatuh, terkena cairan, segel rusak, atau pembongkaran oleh pihak lain.',
 paid:{},rajinCheck:{},adminUnitFee:4000,adminOmzetRate:1,rajinRate:2,ownerPhone:'',ownerPinH:'',
 staff:[{id:'adm',name:'Admin Depan',role:'admin',base:1500000,share:0,fee:0},
  {id:'t-int',name:'Teknisi 1',role:'interface',base:0,share:30,fee:2},
  {id:'t-exp',name:'Teknisi 2',role:'expert',base:0,share:40,fee:2}]};}
function defaultPrefs(){return{theme:'auto',fs:'m',paper:32,pmode:'img',autoPrint:false,chunk:100,btName:'',hint:false,sopSetujui:false};}

var cfg=defaultCfg(),txs=[],exps=[],DOCS={},IDB=null,PREFS=defaultPrefs();
var SYNC={url:'',token:'1ZluH9xw20_MoCtch428PVuNuwyJHJt_cTmqd9OvNzGw',since:0,pending:{},last:0,state:'idle',err:'',linked:false};
var BT={dev:null,ch:null,name:''},syncing=false,installEv=null,syncTimer=null;
var tab='kasir',aturTab='toko',month=iso(new Date()).slice(0,7),day=iso(new Date()),dayAuto=true;
var draft=newDraft(),expDraft=newExp(),lastSaved=null,openTx=null,armed=null,showImg=null;
var flt='hari',msgT='terima',cancelD={id:null,reason:''},claimD={id:null,issue:'',result:CLAIMRES[0],cost:0};
var claimEdit={id:null,ci:-1},apprD={id:null,ci:-1,mode:'ok',pin:''},editD={id:null,items:null,pin:''};
var imgCache={key:'',url:''},SIGC={},sigPad={drawing:false};
var CANPICK=!!(navigator.contacts&&navigator.contacts.select);

function iso(d){var m=d.getMonth()+1,x=d.getDate();return d.getFullYear()+'-'+(m<10?'0':'')+m+'-'+(x<10?'0':'')+x;}
function pd(s){var p=s.split('-');return new Date(+p[0],+p[1]-1,+p[2]);}
function addDays(s,n){var d=pd(s);d.setDate(d.getDate()+n);return iso(d);}
function diffDays(a,b){return Math.round((pd(b)-pd(a))/86400000);}
function rp(n){return (n<0?'-':'')+'Rp '+Math.abs(Math.round(n||0)).toLocaleString('id-ID');}
function nm(n){return Math.round(n||0).toLocaleString('id-ID');}
function pct(n){return String(Math.round((+n||0)*100)/100).replace('.',',')+'%';}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,6);}
function fdate(s){var p=(s||'').split('-');return p.length===3?(+p[2])+' '+BULAN[+p[1]-1].slice(0,3)+' '+p[0]:(s||'');}
function mlabel(m){var p=m.split('-');return BULAN[+p[1]-1]+' '+p[0];}
function inM(d,m){return !!d&&d.slice(0,7)===m;}
function sleep(ms){return new Promise(function(r){setTimeout(r,ms);});}
function typing(){var a=document.activeElement;return !!(a&&/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName));}
function hashPin(s){var x=5381;s='adob|'+s;for(var i=0;i<s.length;i++)x=((x<<5)+x+s.charCodeAt(i))|0;return'h'+x;}
function ownerOK(p){return !!cfg.ownerPinH&&hashPin(String(p||''))===cfg.ownerPinH;}
function num(v){var n=parseFloat(String(v==null?'':v).replace(',','.'));return isNaN(n)?0:n;}

function fmtRp(v){if(v===''||v==null)return'';var d=String(v).replace(/\D/g,'').replace(/^0+(?=\d)/,'');return d?(+d).toLocaleString('id-ID'):'';}
function moneyBox(attrs,val){return'<div class="moneyin"><b>Rp</b><input type="text" inputmode="numeric" autocomplete="off" data-money="1" '+attrs+' value="'+esc(fmtRp(val))+'" placeholder="0"></div>';}
function moneyFix(el){
 var raw=el.value,pos=el.selectionStart==null?raw.length:el.selectionStart;
 var before=raw.slice(0,pos).replace(/\D/g,'').length;
 var digits=raw.replace(/\D/g,'').replace(/^0+(?=\d)/,'');
 var out=digits?(+digits).toLocaleString('id-ID'):'';el.value=out;
 var np=0,c=0;
 if(before>0){np=out.length;for(var i=0;i<out.length;i++){if(out.charCodeAt(i)>=48&&out.charCodeAt(i)<=57){c++;if(c===before){np=i+1;break;}}}}
 try{el.setSelectionRange(np,np);}catch(e){}
 return digits?+digits:0;}

function newDraft(){return{customer:'',phone:'',device:'',imei:'',complaint:'',lockType:'none',lockPass:'',lockPat:[],signature:'',pay:'Tunai',techId:'',items:[{type:'jasa',name:'',qty:1,price:''}]};}
function newExp(){return{date:iso(new Date()),cat:CATS[0],note:'',amount:''};}
function staff(id){return cfg.staff.find(function(s){return s.id===id;});}
function admins(){return cfg.staff.filter(function(s){return s.role==='admin';});}
function adminS(){return admins()[0];}
function techs(){return cfg.staff.filter(function(s){return s.role!=='admin';});}
function slabel(s){return s.name+' · '+ROLE[s.role];}
function techName(id){var s=staff(id);return s?s.name:'-';}
function statusOf(t){return t.status||'Diambil';}
function isActive(t){return statusOf(t)!=='Dibatalkan';}
function isProc(t){return isActive(t)&&PROSES.indexOf(statusOf(t))>=0;}
function isFin(t){return statusOf(t)==='Selesai'||statusOf(t)==='Diambil';}
function finDate(t){return t.doneDate||t.date;}
function cancelDate(t){return t.cancelAt||t.date;}
function claimOK(c){return !c.status||c.status==='disetujui';}
function lockLabel(t){return t.lockType==='pass'?'Sandi':t.lockType==='pattern'?'Pola':'Tidak ada';}
function lockInternal(t){return t.lockType==='pass'?'Sandi '+(t.lockPass||'-'):t.lockType==='pattern'?'Pola '+((t.lockPat&&t.lockPat.length)?t.lockPat.join(' → '):'-'):'Tidak ada';}
function warr(t){
 var n=+t.warrantyDays||0;if(!n||!isActive(t))return null;
 if(!isFin(t))return{n:n,started:false};
 var start=finDate(t),until=addDays(start,n),left=diffDays(iso(new Date()),until);
 return{n:n,started:true,start:start,until:until,left:left,active:left>=0};}
function normPhone(p){var d=String(p||'').replace(/\D/g,'');if(!d)return'';if(d.indexOf('62')===0)return d;if(d.charAt(0)==='0')return'62'+d.slice(1);if(d.charAt(0)==='8')return'62'+d;return d;}
function custList(){var seen={},out=[];
 txs.slice().sort(function(a,b){return(b.ts||'').localeCompare(a.ts||'');}).forEach(function(t){var k=(t.customer||'').trim().toLowerCase();if(!k||seen[k])return;seen[k]=1;out.push({name:t.customer.trim(),phone:t.phone||''});});
 return out;}

function loadPrefs(){try{PREFS=Object.assign(defaultPrefs(),JSON.parse(localStorage.getItem('kp-prefs')||'{}'));}catch(e){}}
function savePrefs(){try{localStorage.setItem('kp-prefs',JSON.stringify(PREFS));}catch(e){}}
function applyTheme(){
 var id=PREFS.theme;
 if(id==='auto')id=(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches)?'malam':'hijau';
 var r=document.documentElement;r.setAttribute('data-tema',id);r.setAttribute('data-fs',PREFS.fs);
 var th=THEMES.find(function(x){return x[0]===id;}),m=document.querySelector('meta[name=theme-color]');if(m&&th)m.setAttribute('content',th[2]);}

function idbOpen(){return new Promise(function(res,rej){var r=indexedDB.open('kasir-pro',1);r.onupgradeneeded=function(){r.result.createObjectStore('docs',{keyPath:'k'});};r.onsuccess=function(){res(r.result);};r.onerror=function(){rej(r.error);};});}
function idbAll(){return new Promise(function(res,rej){var q=IDB.transaction('docs','readonly').objectStore('docs').getAll();q.onsuccess=function(){res(q.result);};q.onerror=function(){rej(q.error);};});}
function idbPut(k,v){try{IDB.transaction('docs','readwrite').objectStore('docs').put({k:k,v:v});}catch(e){}}
function persist(k){if(IDB)idbPut(k,DOCS[k]);else try{localStorage.setItem('kp-fallback',JSON.stringify(DOCS));}catch(e){}}
function rebuild(){
 txs=[];exps=[];var c=null;
 Object.keys(DOCS).forEach(function(k){var o=DOCS[k];if(!o||o.deleted)return;if(k.indexOf('tx/')===0)txs.push(o);else if(k.indexOf('exp/')===0)exps.push(o);else if(k==='cfg/main')c=o;});
 cfg=Object.assign(defaultCfg(),c||{});
 if(!cfg.staff||!cfg.staff.length)cfg.staff=defaultCfg().staff;
 cfg.staff.forEach(function(s){
  if(s.role==='admin'){s.share=0;s.fee=0;s.base=+s.base||0;}
  else{s.base=0;if(s.share==null||isNaN(+s.share))s.share=s.role==='expert'?40:30;if(s.fee==null||isNaN(+s.fee))s.fee=2;}
 });}
function put(coll,o){o.updated=Date.now();var k=coll+'/'+o.id;DOCS[k]=o;persist(k);mark(k);rebuild();}
function drop(coll,id){var k=coll+'/'+id,o=DOCS[k];if(!o)return;o.deleted=true;o.updated=Date.now();persist(k);mark(k);rebuild();}
function saveCfg(){cfg.id='main';cfg.updated=Date.now();DOCS['cfg/main']=cfg;persist('cfg/main');mark('cfg/main');}
function findTx(id){return txs.find(function(x){return x.id===id;});}

function loadSync(){try{SYNC=Object.assign(SYNC,JSON.parse(localStorage.getItem('kp-sync')||'{}'));}catch(e){}SYNC.state='idle';}
function saveSync(){try{localStorage.setItem('kp-sync',JSON.stringify({url:SYNC.url,token:SYNC.token,since:SYNC.since,pending:SYNC.pending,last:SYNC.last,linked:SYNC.linked}));}catch(e){}}
function mark(k){SYNC.pending[k]=1;saveSync();scheduleSync(3000);}
function scheduleSync(ms){if(!SYNC.url||!SYNC.token)return;clearTimeout(syncTimer);syncTimer=setTimeout(function(){syncNow(false);},ms);}
function cell(v){var s=v==null?'':String(v);if(/^[=+\-@]/.test(s)||/^0\d/.test(s)||/^\d{9,}$/.test(s))return"'"+s;return s;}
function rowFor(k,o){
 var coll=k.split('/')[0],base=[o.id,o.updated,o.deleted?1:0];
 var js=JSON.stringify(o);if(js.length>48000){var o2=Object.assign({},o);delete o2.signature;js=JSON.stringify(o2);}
 if(coll==='tx'){var c=calc(o),w=warr(o);
  return base.concat([o.date,cell(o.no),cell(o.customer),cell(o.phone),cell(o.device),cell(o.imei),cell(o.complaint),techName(o.techId),statusOf(o),o.pay,
   cell((o.items||[]).map(function(i){return i.name+' x'+(i.qty||1)+' @'+i.price;}).join('; ')),c.jasa,c.partRev,c.partCost,c.total,Math.round(c.tech),0,Math.round(c.shop),o.warrantyDays||0,(w&&w.until)||'',(o.claims||[]).length,js]);}
 if(coll==='exp')return base.concat([o.date,cell(o.cat),cell(o.note),+o.amount||0,js]);
 return base.concat(['Pengaturan toko',js]);}
function api(body){
 body.token=SYNC.token;var ctl=new AbortController(),tm=setTimeout(function(){ctl.abort();},45000);
 return fetch(SYNC.url,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(body),redirect:'follow',signal:ctl.signal})
  .then(function(r){clearTimeout(tm);return r.json();}).catch(function(e){clearTimeout(tm);throw e;});}
function pendingCount(){return Object.keys(SYNC.pending).length;}
function syncLabel(){
 if(!SYNC.url||!SYNC.token)return{c:'',t:'Belum terhubung ke Google Sheets'};
 var n=pendingCount();
 if(SYNC.state==='busy')return{c:'wait',t:'Menyinkronkan…'};
 if(SYNC.state==='error')return{c:'err',t:'Gagal sinkron · '+n+' menunggu · ketuk untuk detail'};
 if(SYNC.state==='offline')return{c:'wait',t:'Offline · '+n+' menunggu sinkron'};
 if(n)return{c:'wait',t:n+' data menunggu sinkron'};
 return{c:'ok',t:'Tersinkron ke Google Sheets'+(SYNC.last?' · '+new Date(SYNC.last).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}):'')};}
function statusRefresh(){var b=document.querySelector('.sub');if(!b)return;var sl=syncLabel();b.className='sub '+sl.c;b.innerHTML='<span class="dot"></span>'+esc(sl.t);}
async function syncNow(manual){
 if(!SYNC.url||!SYNC.token){if(manual)toast('Isi tautan Apps Script dan kode rahasia di Atur › Google Sheets.');return;}
 if(syncing)return;
 if(typeof navigator.onLine==='boolean'&&!navigator.onLine){SYNC.state='offline';statusRefresh();if(manual)toast('Perangkat offline. Data disinkronkan saat tersambung.');return;}
 syncing=true;SYNC.state='busy';statusRefresh();var changed=false;
 try{
  var by={tx:[],exp:[],cfg:[]};
  Object.keys(SYNC.pending).forEach(function(k){if(!DOCS[k]){delete SYNC.pending[k];return;}var c=k.split('/')[0];if(by[c])by[c].push(k);});
  for(var coll in by){var ks=by[coll];
   for(var i=0;i<ks.length;i+=40){var part=ks.slice(i,i+40),snap={};
    part.forEach(function(k){snap[k]=DOCS[k].updated;});
    var r=await api({action:'push',coll:coll,headers:HEAD[coll],docs:part.map(function(k){return{row:rowFor(k,DOCS[k])};})});
    if(!r||!r.ok)throw new Error((r&&r.error)||'push');
    part.forEach(function(k){if(DOCS[k]&&DOCS[k].updated===snap[k])delete SYNC.pending[k];});
    saveSync();}}
  var pr=await api({action:'pull',since:SYNC.since});
  if(!pr||!pr.ok)throw new Error((pr&&pr.error)||'pull');
  var maxU=SYNC.since;
  (pr.docs||[]).forEach(function(d){
   if(d.updated>maxU)maxU=d.updated;
   var loc=DOCS[d.k];if(loc&&loc.updated>=d.updated)return;
   var o;try{o=JSON.parse(d.json);}catch(e){return;}
   o.updated=d.updated;if(d.deleted)o.deleted=true;DOCS[d.k]=o;persist(d.k);delete SYNC.pending[d.k];changed=true;});
  SYNC.since=maxU;SYNC.last=Date.now();SYNC.state='idle';SYNC.err='';saveSync();
  if(changed)rebuild();
  if(manual)toast('Sinkronisasi selesai.');
 }catch(e){
  SYNC.state='error';SYNC.err=(e&&e.message)||'gagal';
  if(manual)toast(SYNC.err==='token'?'Kode rahasia tidak cocok dengan skrip.':'Sinkronisasi gagal. Periksa koneksi internet.');
 }
 syncing=false;statusRefresh();
 if((changed||tab==='atur')&&!typing())render();}

/* RUMUS FINAL:
 Laba bersih = total nota - modal sparepart
 Bagi hasil teknisi = laba bersih x share%
 Toko awal = laba bersih - bagi hasil
 Fee unit = toko awal x fee%
 Total teknisi = bagi hasil + fee
 Sisa toko = toko awal - fee */
function calc(t){
 var jasa=0,pr=0,pc=0;
 (t.items||[]).forEach(function(i){var q=+i.qty||1;if(i.type==='jasa')jasa+=q*(+i.price||0);else{pr+=q*(+i.price||0);pc+=q*(+i.cost||0);}});
 var total=jasa+pr,net=Math.max(0,total-pc),s=staff(t.techId),isT=!!(s&&s.role!=='admin');
 var share=(t.share!=null)?num(t.share):(isT?num(s.share):0);
 var fee=(t.fee!=null)?num(t.fee):(isT?num(s.fee):0);
 var bh=net*share/100,shop0=net-bh,feeAmt=shop0*fee/100;
 return{jasa:jasa,partRev:pr,partCost:pc,total:total,net:net,share:share,fee:fee,bh:bh,shop0:shop0,feeAmt:feeAmt,tech:bh+feeAmt,shop:shop0-feeAmt};}

function monthStats(m){
 var F=txs.filter(function(t){return isActive(t)&&isFin(t)&&inM(finDate(t),m);});
 var E=exps.filter(function(e){return inM(e.date,m);});
 var a={nMasuk:0,nProses:0,nSelesai:F.length,nBatal:0,total:0,jasa:0,partRev:0,partCost:0,net:0,bh:0,feeAmt:0,tech:0,shop0:0,shop:0,byTech:{},byCat:{},days:{},claimCost:0,claimN:0,exp:0,expN:E.length};
 function bt(id){return a.byTech[id]||(a.byTech[id]={masuk:0,proses:0,selesai:0,batal:0,net:0,bh:0,feeAmt:0,tech:0,shop:0});}
 function dr(d){return a.days[d]||(a.days[d]={masuk:0,selesai:0,batal:0,total:0,net:0,tech:0,shop:0});}
 txs.forEach(function(t){
  if(inM(t.date,m)){a.nMasuk++;bt(t.techId).masuk++;dr(t.date).masuk++;if(isProc(t)){a.nProses++;bt(t.techId).proses++;}}
  if(!isActive(t)&&inM(cancelDate(t),m)){a.nBatal++;bt(t.techId).batal++;dr(cancelDate(t)).batal++;}
 });
 F.forEach(function(t){var c=calc(t),b=bt(t.techId),d=dr(finDate(t));
  a.total+=c.total;a.jasa+=c.jasa;a.partRev+=c.partRev;a.partCost+=c.partCost;a.net+=c.net;a.bh+=c.bh;a.feeAmt+=c.feeAmt;a.tech+=c.tech;a.shop0+=c.shop0;a.shop+=c.shop;
  b.selesai++;b.net+=c.net;b.bh+=c.bh;b.feeAmt+=c.feeAmt;b.tech+=c.tech;b.shop+=c.shop;
  d.selesai++;d.total+=c.total;d.net+=c.net;d.tech+=c.tech;d.shop+=c.shop;});
 txs.forEach(function(t){(t.claims||[]).forEach(function(c){if(claimOK(c)&&inM(c.date,m)){a.claimN++;a.claimCost+=+c.cost||0;}});});
 E.forEach(function(e){a.exp+=+e.amount||0;a.byCat[e.cat]=(a.byCat[e.cat]||0)+(+e.amount||0);});
 a.base=admins().reduce(function(x,s){return x+(+s.base||0);},0);
 a.adminUnit=F.length*(+cfg.adminUnitFee||0);
 a.adminOmzet=a.net*num(cfg.adminOmzetRate)/100;
 a.adminBonus=a.adminUnit+a.adminOmzet;
 a.rajinPool=a.shop*num(cfg.rajinRate)/100;
 var pr=0;cfg.staff.forEach(function(s){if(cfg.rajinCheck&&cfg.rajinCheck[m+'|'+s.id])pr+=a.rajinPool;});
 a.totalRajinPaid=pr;
 a.payroll=a.base+a.tech+a.adminBonus+pr;
 a.netShop=a.shop-a.base-a.adminBonus-pr-a.exp-a.claimCost;
 a.ratio=a.net>0?a.payroll/a.net:0;
 return a;}

function dayStats(d){
 var o={masuk:0,proses:0,selesai:0,diambil:0,batal:0,total:0,net:0,bh:0,feeAmt:0,tech:0,shop:0,byTech:{}};
 function bt(id){return o.byTech[id]||(o.byTech[id]={masuk:0,proses:0,selesai:0,diambil:0,batal:0,net:0,bh:0,feeAmt:0,tech:0});}
 txs.forEach(function(t){
  if(t.date===d){o.masuk++;bt(t.techId).masuk++;}
  if(isProc(t)){o.proses++;bt(t.techId).proses++;}
  if(isActive(t)&&isFin(t)&&finDate(t)===d){var c=calc(t),b=bt(t.techId);
   o.selesai++;o.total+=c.total;o.net+=c.net;o.bh+=c.bh;o.feeAmt+=c.feeAmt;o.tech+=c.tech;o.shop+=c.shop;
   b.selesai++;b.net+=c.net;b.bh+=c.bh;b.feeAmt+=c.feeAmt;b.tech+=c.tech;}
  if(statusOf(t)==='Diambil'&&t.pickDate===d){o.diambil++;bt(t.techId).diambil++;}
  if(!isActive(t)&&cancelDate(t)===d){o.batal++;bt(t.techId).batal++;}
 });
 return o;}
function nextNo(date){var n=Object.keys(DOCS).filter(function(k){return k.indexOf('tx/')===0&&DOCS[k].date===date;}).length+1;return'N-'+date.slice(2,4)+date.slice(5,7)+date.slice(8,10)+'-'+('00'+n).slice(-3);}

function wrap(s,w){var out=[],cur='';String(s||'').split(/\s+/).forEach(function(x){
 while(x.length>w){if(cur){out.push(cur);cur='';}out.push(x.slice(0,w));x=x.slice(w);}
 if(!x)return;if(!cur)cur=x;else if((cur+' '+x).length<=w)cur+=' '+x;else{out.push(cur);cur=x;}});if(cur)out.push(cur);return out;}
function ctr(s,w){return wrap(s,w).map(function(l){return new Array(Math.max(0,Math.floor((w-l.length)/2))+1).join(' ')+l;});}
function lr(l,r,w){l=String(l);r=String(r);var sp=w-l.length-r.length;if(sp<1)return l.slice(0,Math.max(1,w-r.length-1))+' '+r;return l+new Array(sp+1).join(' ')+r;}
function kvT(k,v,W){var pre=(k+'           ').slice(0,10)+': ',pad=new Array(pre.length+1).join(' ');return wrap(v,W-pre.length).map(function(l,i){return(i?pad:pre)+l;});}
function notaText(t,o){
 o=o||{};var W=+PREFS.paper||32,c=calc(t),L=[],dash=new Array(W+1).join('-'),eq=new Array(W+1).join('=');
 if(!o.noHead){L=L.concat(ctr(String(cfg.shop).toUpperCase(),W));if(cfg.addr)L=L.concat(ctr(cfg.addr,W));if(cfg.phone)L=L.concat(ctr('Telp/WA '+cfg.phone,W));}
 L.push(eq,lr('NOTA SERVIS',t.no,W),eq,lr('Tanggal',fdate(t.date),W));
 if(t.customer)L=L.concat(kvT('Pelanggan',t.customer,W));
 if(t.phone)L=L.concat(kvT('No. HP',t.phone,W));
 L.push(lr('Teknisi',techName(t.techId),W),dash,'DATA UNIT');
 if(t.device)L=L.concat(kvT('Perangkat',t.device,W));
 if(t.imei)L=L.concat(kvT('IMEI/SN',t.imei,W));
 if(t.complaint)L=L.concat(kvT('Keluhan',t.complaint,W));
 if(t.lockType&&t.lockType!=='none')L=L.concat(kvT('Kunci',lockLabel(t),W));
 L.push(dash,'RINCIAN');
 (t.items||[]).forEach(function(i){var q=+i.qty||1;L=L.concat(wrap(i.name,W));L.push(lr('  '+q+' x '+nm(i.price),nm(q*(+i.price||0)),W));});
 L.push(eq,lr('TOTAL',rp(c.total),W),lr('Bayar',t.pay,W),eq);
 if(+t.warrantyDays>0){L=L.concat(ctr('** GARANSI '+t.warrantyDays+' HARI **',W));L=L.concat(ctr('Berlaku sejak pekerjaan selesai.',W));if(cfg.terms)L=L.concat(wrap(cfg.terms,W));L.push(dash);}
 if(t.signature)L.push('TTD pelanggan: tercatat digital');
 L=L.concat(ctr('Terima kasih atas kepercayaan Anda',W));L=L.concat(ctr('Simpan nota ini untuk pengambilan unit.',W));L.push('','');
 return L.join('\n');}
function ascii(s){s=String(s==null?'':s);if(s.normalize)s=s.normalize('NFD').replace(/[\u0300-\u036f]/g,'');return s.replace(/[^\x20-\x7E]/g,'-');}
function textBytes(t){
 var B=[27,64],W=+PREFS.paper||32;
 function T(s){s=ascii(s);for(var i=0;i<s.length;i++)B.push(s.charCodeAt(i));B.push(10);}
 B.push(27,97,1,27,69,1,29,33,17);wrap(ascii(cfg.shop).toUpperCase(),Math.floor(W/2)).forEach(T);B.push(29,33,0,27,69,0);
 if(cfg.addr)wrap(ascii(cfg.addr),W).forEach(T);if(cfg.phone)T('Telp/WA '+cfg.phone);
 B.push(27,97,0);notaText(t,{noHead:true}).split('\n').forEach(T);B.push(27,100,3,29,86,66,0);return new Uint8Array(B);}
function sigImg(src){if(!src)return null;var im=SIGC[src];
 if(!im){im=new Image();im.onload=function(){imgCache={key:'',url:''};if(!typing())render();};im.src=src;SIGC[src]=im;}
 return(im.complete&&im.naturalWidth)?im:null;}
function preSig(t){return new Promise(function(res){
 if(!t.signature)return res();var im=SIGC[t.signature];if(im&&im.complete&&im.naturalWidth)return res();
 im=new Image();im.onload=im.onerror=function(){SIGC[t.signature]=im;res();};im.src=t.signature;});}
function drawNota(t){
 var W=(+PREFS.paper===48)?576:384,M=Math.round(W*0.04)+2,CW=W-2*M,H=4200,K=W>400?1.15:1;
 var cv=document.createElement('canvas');cv.width=W;cv.height=H;var x=cv.getContext('2d');
 x.fillStyle='#fff';x.fillRect(0,0,W,H);x.fillStyle='#000';x.strokeStyle='#000';x.textBaseline='top';
 var SANS='"IBM Plex Sans",system-ui,Arial,sans-serif',MONO='"IBM Plex Mono",ui-monospace,monospace',DISP='Archivo,"Arial Narrow",Arial,sans-serif',y=16;
 function fs(n){return Math.round(n*K);}
 function setF(wt,size,fam){x.font=wt+' '+fs(size)+'px '+fam;}
 function lines(str,maxw){var out=[],cur='';
  String(str||'').split(/\s+/).forEach(function(w){if(!w)return;var tr=cur?cur+' '+w:w;
   if(x.measureText(tr).width<=maxw){cur=tr;return;}if(cur){out.push(cur);cur='';}
   while(x.measureText(w).width>maxw&&w.length>1){var k=w.length;while(k>1&&x.measureText(w.slice(0,k)).width>maxw)k--;out.push(w.slice(0,k));w=w.slice(k);}cur=w;});
  if(cur)out.push(cur);return out;}
 function cen(str,wt,size,fam,lh,inset){setF(wt,size,fam);x.textAlign='center';lines(str,CW-(inset||0)*2).forEach(function(l){x.fillText(l,W/2,y);y+=fs(lh);});}
 function dash(){x.save();x.setLineDash([5,4]);x.lineWidth=1.5;x.beginPath();x.moveTo(M,y+3);x.lineTo(W-M,y+3);x.stroke();x.restore();y+=12;}
 function solid(w){x.lineWidth=w;x.beginPath();x.moveTo(M,y);x.lineTo(W-M,y);x.stroke();y+=w+8;}
 function sec(s){setF('800',12,DISP);x.textAlign='left';x.fillText(s,M,y);y+=fs(17);}
 function kv(k,v){if(!v)return;var lw=Math.round(CW*0.3);setF('600',14,SANS);x.textAlign='left';x.fillText(k,M,y);x.fillText(':',M+lw-9,y);
  setF('500',14,SANS);lines(v,CW-lw).forEach(function(l){x.fillText(l,M+lw,y);y+=fs(18);});}
 function bar(l,r){var h=fs(28);x.fillStyle='#000';x.fillRect(M,y,CW,h);x.fillStyle='#fff';setF('800',15,DISP);x.textAlign='left';x.fillText(l,M+8,y+fs(5));
  setF('700',14,MONO);x.textAlign='right';x.fillText(r,W-M-8,y+fs(6));x.fillStyle='#000';y+=h+10;}
 var c=calc(t);
 cen(String(cfg.shop).toUpperCase(),'800',26,DISP,30);
 if(cfg.addr)cen(cfg.addr,'500',13,SANS,17);if(cfg.phone)cen('Telp/WA '+cfg.phone,'600',13,SANS,17);
 y+=6;solid(3);bar('NOTA SERVIS',t.no);
 kv('Tanggal',fdate(t.date));kv('Pelanggan',t.customer);kv('No. HP',t.phone);kv('Teknisi',techName(t.techId));
 y+=2;dash();sec('DATA UNIT');kv('Perangkat',t.device);kv('IMEI / SN',t.imei);kv('Keluhan',t.complaint);
 if(t.lockType&&t.lockType!=='none')kv('Kunci layar',lockLabel(t));
 y+=2;dash();sec('RINCIAN PEKERJAAN');
 (t.items||[]).forEach(function(i){var q=+i.qty||1;
  setF('700',15,SANS);x.textAlign='left';lines(i.name,CW).forEach(function(l){x.fillText(l,M,y);y+=fs(20);});
  setF('500',14,MONO);x.textAlign='left';x.fillText(q+' x '+nm(i.price),M+8,y);
  setF('700',15,MONO);x.textAlign='right';x.fillText(nm(q*(+i.price||0)),W-M,y);y+=fs(26);});
 solid(2);setF('800',18,DISP);x.textAlign='left';x.fillText('TOTAL',M,y+fs(5));
 setF('700',24,MONO);x.textAlign='right';x.fillText('Rp '+nm(c.total),W-M,y);y+=fs(36);
 setF('500',14,SANS);x.textAlign='left';x.fillText('Pembayaran',M,y);setF('700',14,SANS);x.textAlign='right';x.fillText(t.pay||'-',W-M,y);y+=fs(22);
 solid(2);
 if(+t.warrantyDays>0){var y0=y;y+=8;cen('GARANSI '+t.warrantyDays+' HARI','800',17,DISP,22,6);cen('Berlaku sejak pekerjaan selesai','500',12,SANS,16,6);
  if(cfg.terms)cen(cfg.terms,'400',11,SANS,15,6);y+=6;x.lineWidth=2;x.strokeRect(M,y0,CW,y-y0);y+=14;}
 if(t.signature){var im=sigImg(t.signature);y+=4;sec('TANDA TANGAN PELANGGAN');if(im){x.drawImage(im,M,y,150,50);y+=56;}}
 y+=2;cen('Terima kasih atas kepercayaan Anda','700',15,SANS,20);
 cen('Mohon simpan nota ini dan bawa saat pengambilan unit.','400',12,SANS,16);y+=4;cen('* * * * *','700',14,MONO,18);
 var out=document.createElement('canvas');out.width=W;out.height=Math.min(H,Math.ceil(y)+22);
 var ox=out.getContext('2d');ox.fillStyle='#fff';ox.fillRect(0,0,out.width,out.height);ox.drawImage(cv,0,0);return out;}
function notaImgURL(t){
 var key=JSON.stringify([t.id,t.items,t.pay,t.warrantyDays,t.no,t.techId,t.signature?t.signature.length:0,PREFS.paper,cfg.shop,cfg.addr,cfg.phone,cfg.terms]);
 if(imgCache.key===key)return imgCache.url;
 try{var u=drawNota(t).toDataURL('image/png');imgCache={key:key,url:u};return u;}catch(e){return'';}}
function rasterBytes(cv){
 var w=cv.width,h=cv.height,d=cv.getContext('2d').getImageData(0,0,w,h).data,wb=w>>3,B=[],band=64;B.push(27,64);
 for(var y0=0;y0<h;y0+=band){var bh=Math.min(band,h-y0);B.push(29,118,48,0,wb&255,wb>>8,bh&255,bh>>8);
  for(var y=0;y<bh;y++)for(var xb=0;xb<wb;xb++){var by=0;
   for(var bit=0;bit<8;bit++){var p=((y0+y)*w+(xb<<3)+bit)*4,lum=d[p]*0.299+d[p+1]*0.587+d[p+2]*0.114;if(lum<150)by|=0x80>>bit;}B.push(by);}}
 B.push(27,100,4,29,86,66,0);return new Uint8Array(B);}

function btSupported(){return!!(navigator.bluetooth&&navigator.bluetooth.requestDevice);}
async function btFindChar(srv){
 for(var i=0;i<SVC.length;i++){try{var s=await srv.getPrimaryService(SVC[i]);var cs=await s.getCharacteristics();
  for(var j=0;j<cs.length;j++)if(cs[j].properties.write||cs[j].properties.writeWithoutResponse)return cs[j];}catch(e){}}
 var all=[];try{all=await srv.getPrimaryServices();}catch(e){}
 for(var a=0;a<all.length;a++){var c2=[];try{c2=await all[a].getCharacteristics();}catch(e){}
  for(var b=0;b<c2.length;b++)if(c2[b].properties.write||c2[b].properties.writeWithoutResponse)return c2[b];}
 return null;}
async function btAttach(dev){
 if(!dev._kp){dev._kp=1;dev.addEventListener('gattserverdisconnected',function(){BT.ch=null;if(!typing())render();});}
 var srv=await dev.gatt.connect(),ch=await btFindChar(srv);if(!ch)throw new Error('nochar');
 BT.dev=dev;BT.ch=ch;BT.name=dev.name||'Printer';PREFS.btName=BT.name;savePrefs();}
function btConnect(){return navigator.bluetooth.requestDevice({acceptAllDevices:true,optionalServices:SVC}).then(btAttach);}
async function btEnsure(){if(BT.ch&&BT.dev&&BT.dev.gatt.connected)return;if(BT.dev){try{await btAttach(BT.dev);return;}catch(e){}}await btConnect();}
async function btSend(bytes){var ch=BT.ch,n=+PREFS.chunk||100,nr=!!ch.properties.writeWithoutResponse;
 for(var i=0;i<bytes.length;i+=n){var part=bytes.slice(i,i+n);if(nr)await ch.writeValueWithoutResponse(part);else await ch.writeValue(part);await sleep(nr?14:2);}}
function btErr(e){var n=e&&e.name,m=e&&e.message;
 if(n==='NotFoundError'||/cancel/i.test(m||''))return'Pemilihan printer dibatalkan.';
 if(m==='nochar')return'Printer tidak menyediakan jalur cetak BLE. Gunakan tombol Bagikan.';
 if(n==='SecurityError')return'Browser tidak mengizinkan Bluetooth. Buka lewat HTTPS.';
 return'Printer belum dapat dihubungi. Pastikan printer menyala dan mendukung Bluetooth LE.';}
async function printTx(t){
 if(!btSupported()){toast('Browser belum mendukung Bluetooth langsung. Gunakan Chrome Android atau tombol Bagikan.');return;}
 try{await btEnsure();toast('Mengirim nota ke printer…');await preSig(t);
  await btSend(PREFS.pmode==='text'?textBytes(t):rasterBytes(drawNota(t)));toast('Nota terkirim ke printer.');}
 catch(e){toast(btErr(e));}}
async function testPrint(){
 if(!btSupported()){toast('Browser belum mendukung Bluetooth langsung.');return;}
 try{await btEnsure();var B=[27,64,27,97,1,27,69,1,29,33,17];
  var T=function(s){for(var i=0;i<s.length;i++)B.push(s.charCodeAt(i));B.push(10);};
  T('TES CETAK');B.push(29,33,0,27,69,0);T(ascii(cfg.shop));T('Printer terhubung dengan baik.');B.push(27,100,4,29,86,66,0);
  await btSend(new Uint8Array(B));toast('Tes cetak terkirim.');}catch(e){toast(btErr(e));}}

function greet(){var h=new Date().getHours();return h<11?'Selamat pagi':h<15?'Selamat siang':h<18?'Selamat sore':'Selamat malam';}
function unitDesc(t){return(t.device||'perangkat Anda')+(t.imei?' (IMEI/SN '+t.imei+')':'');}
function waHead(t){return'Yth. Bapak/Ibu '+(t.customer||'Pelanggan')+'\n\n'+greet()+', saya dari *'+cfg.shop+'*.\n\n';}
function waFoot(){return'\n\nHormat kami,\n\n*'+cfg.shop+'*'+(cfg.phone?'\nTelp/WA: '+cfg.phone:'')+(cfg.addr?'\n'+cfg.addr:'');}
function itemList(t){return(t.items||[]).map(function(i){return'• '+i.name+' ('+(+i.qty||1)+' × '+rp(i.price)+')';}).join('\n');}
function msgText(t,type){
 var c=calc(t),w=warr(t),dev=unitDesc(t),H=waHead(t),F=waFoot(),no=t.no;
 if(type==='terima')return H+'Terima kasih telah mempercayakan perangkat Anda kepada kami. Berikut bukti penerimaan unit:\n\n• No. Nota: '+no+'\n• Tanggal: '+fdate(t.date)+'\n• Perangkat: '+dev+(t.complaint?'\n• Keluhan: '+t.complaint:'')+'\n\nRincian pekerjaan:\n'+itemList(t)+'\n\nEstimasi total biaya: *'+rp(c.total)+'*\n\nUnit akan diperiksa dan dikerjakan secara profesional. Perkembangan akan kami kabari melalui WhatsApp ini.\n\nTerima kasih. 🙏'+F;
 if(type==='proses')return H+'Kami informasikan bahwa unit Anda sedang dalam proses pengerjaan oleh teknisi kami, *'+techName(t.techId)+'*.\n\nKami akan segera mengabari setelah pengerjaan selesai. Mohon kesabaran Bapak/Ibu.\n\nTerima kasih atas kepercayaannya. 🙏'+F;
 if(type==='konfirmasi')return H+'Setelah pemeriksaan, berikut rincian perbaikan pada unit Anda:\n\n'+itemList(t)+'\n\nTotal biaya: *'+rp(c.total)+'*\n\nApabila Bapak/Ibu menyetujui, mohon balas pesan ini dengan kata *SETUJU* agar perbaikan segera kami proses. Bila ada keberatan, kami siap menjelaskan terlebih dahulu.'+F;
 if(type==='selesai')return H+'Kabar baik! Unit Anda telah selesai dikerjakan dan dapat diambil di toko kami.\n\n• No. Nota: '+no+'\n• Total biaya: *'+rp(c.total)+'*\n• Pembayaran: '+t.pay+(+t.warrantyDays>0?'\n• Garansi: '+t.warrantyDays+' hari'+(w&&w.started?' (s.d. '+fdate(w.until)+')':''):'')+'\n\nMohon membawa nota ini saat pengambilan unit. Terima kasih atas kepercayaan Bapak/Ibu. 🙏'+F;
 if(type==='garansi'){
  if(!(+t.warrantyDays>0))return H+'Kami informasikan bahwa pekerjaan pada nota '+no+' tidak disertai garansi. Apabila ada yang ingin ditanyakan, silakan hubungi kami.'+F;
  return H+'Berikut informasi garansi unit Anda:\n\n• No. Nota: '+no+'\n• Masa garansi: '+t.warrantyDays+' hari'+(w&&w.started?'\n• Berlaku sampai: '+fdate(w.until):'')+'\n• Perangkat: '+dev+'\n\nKetentuan garansi:\n'+(cfg.terms||'-')+'\n\nBila ada kendala, silakan bawa unit beserta nota ini ke toko kami.'+F;}
 return H+'Kami informasikan bahwa pengerjaan nota '+no+' untuk unit '+dev+' telah dibatalkan'+(t.cancelReason?'\n\nAlasan: '+t.cancelReason:'')+'.\n\nTerima kasih atas pengertian Bapak/Ibu. 🙏'+F;}
function waLink(t,msg){return'https://wa.me/'+normPhone(t.phone)+'?text='+encodeURIComponent(msg);}
function waOwner(t,cl){
 var m='*PERMOHONAN ACC KLAIM GARANSI*\n\nToko: '+cfg.shop+'\nNota: '+t.no+'\nPelanggan: '+(t.customer||'-')+'\nPerangkat: '+(t.device||'-')+'\nTanggal klaim: '+fdate(cl.date)+'\nKeluhan: '+cl.issue+'\nTindak lanjut: '+cl.result+'\nBiaya ditanggung toko: '+rp(cl.cost)+'\n\nMohon balas *ACC* atau *TOLAK*.';
 return'https://wa.me/'+normPhone(cfg.ownerPhone)+'?text='+encodeURIComponent(m);}

function view(){var f={kasir:vKasir,riwayat:vNota,gaji:vGaji,biaya:vBiaya,laporan:vLaporan,atur:vAtur}[tab]||vKasir;
 try{return f();}catch(e){return'<section class="card stack"><strong>Halaman gagal dimuat</strong><span class="small muted">'+esc(e&&e.message)+'</span><div><button class="btn sm" data-act="tab" data-v="kasir">Kembali ke Input Data</button></div></section>';}}
function shell(){
 var tabs=[['kasir','Input Data'],['riwayat','Nota'],['gaji','Gaji'],['biaya','Biaya'],['laporan','Laporan'],['atur','Atur']];
 var showMon=['gaji','biaya','laporan'].indexOf(tab)>=0||(tab==='riwayat'&&(flt==='bulan'||flt==='batal')),sl=syncLabel();
 return'<div class="wrap"><header class="top"><div><h1>'+esc(cfg.shop)+'</h1><button class="sub '+sl.c+'" data-act="go-sheets"><span class="dot"></span>'+esc(sl.t)+'</button></div>'+
  (showMon?'<div class="mon"><button data-act="mon" data-v="-1" aria-label="Bulan sebelumnya">‹</button><strong>'+mlabel(month)+'</strong><button data-act="mon" data-v="1" aria-label="Bulan berikutnya">›</button></div>':'')+
  '</header><main>'+view()+'</main></div><nav class="tabs"><div class="wrap tabs-in">'+
  tabs.map(function(t){return'<button class="tab" data-act="tab" data-v="'+t[0]+'"'+(tab===t[0]?' aria-current="page"':'')+'>'+t[1]+'</button>';}).join('')+'</div></nav>';}
function render(){
 var ae=document.activeElement,id=ae&&ae.id,ss=null,se=null,y=window.scrollY;
 try{ss=ae.selectionStart;se=ae.selectionEnd;}catch(e){}
 document.getElementById('app').innerHTML=shell();
 if(id){var el=document.getElementById(id);if(el){el.focus({preventScroll:true});try{if(ss!=null)el.setSelectionRange(ss,se);}catch(e){}}}
 window.scrollTo(0,y);initSigPad();}
var tt;function toast(m){var t=document.getElementById('toast');t.textContent=m;t.classList.add('on');clearTimeout(tt);tt=setTimeout(function(){t.classList.remove('on');},3800);}
function emptyBlock(t,s,sample){return'<section class="card"><div class="empty"><strong>'+esc(t)+'</strong><span>'+esc(s)+'</span>'+(sample?'<button class="btn" data-act="sample">Isi data contoh</button>':'')+'</div></section>';}
function splitLedger(c,name){
 return'<div class="ledger"><div class="ln"><span>Total nota</span><span class="num">'+rp(c.total)+'</span></div>'+
 '<div class="ln"><span>Modal sparepart</span><span class="num">− '+rp(c.partCost)+'</span></div>'+
 '<div class="ln tot"><span>Laba bersih</span><span class="num">'+rp(c.net)+'</span></div>'+
 '<div class="ln"><span>Bagi hasil '+esc(name||'teknisi')+' ('+pct(c.share)+')</span><span class="num">'+rp(c.bh)+'</span></div>'+
 '<div class="ln sub"><span>Bagian toko awal</span><span class="num">'+rp(c.shop0)+'</span></div>'+
 '<div class="ln"><span>Fee unit teknisi ('+pct(c.fee)+' × toko awal)</span><span class="num">'+rp(c.feeAmt)+'</span></div>'+
 '<div class="ln tot"><span>Total teknisi</span><span class="num pos">'+rp(c.tech)+'</span></div>'+
 '<div class="ln tot"><span>Sisa toko</span><span class="num">'+rp(c.shop)+'</span></div></div>';}
function sumHTML(){var t=staff(draft.techId),c=calc({items:draft.items,techId:draft.techId});
 return'<h3 style="margin-bottom:6px">Ringkasan &amp; pembagian</h3><div class="ledger"><div class="ln"><span>Jasa</span><span class="num">'+rp(c.jasa)+'</span></div><div class="ln"><span>Sparepart (harga jual)</span><span class="num">'+rp(c.partRev)+'</span></div></div>'+splitLedger(c,t?t.name:'');}
function printBtns(t){var pr=btSupported();
 return'<div class="row">'+(pr?'<button class="btn pri sm" data-act="print" data-v="'+t.id+'">Cetak ke printer</button>':'')+'<button class="btn sm'+(pr?'':' pri')+'" data-act="share-img" data-v="'+t.id+'">Bagikan gambar nota</button><button class="btn sm" data-act="dl-img" data-v="'+t.id+'">Unduh PNG</button><button class="btn sm" data-act="copy-tx" data-v="'+t.id+'">Salin teks</button></div>';}

function initSigPad(){
 var cv=document.getElementById('sig-canvas');if(!cv)return;
 var r=cv.getBoundingClientRect();cv.width=Math.max(200,Math.round(r.width));cv.height=130;
 var x=cv.getContext('2d');x.strokeStyle='#111';x.lineWidth=2.5;x.lineCap='round';x.lineJoin='round';
 if(draft.signature){var im=new Image();im.onload=function(){x.drawImage(im,0,0,cv.width,cv.height);};im.src=draft.signature;}
 var pos=function(e){var b=cv.getBoundingClientRect();return[e.clientX-b.left,e.clientY-b.top];};
 cv.onpointerdown=function(e){sigPad.drawing=true;try{cv.setPointerCapture(e.pointerId);}catch(_){}var p=pos(e);x.beginPath();x.moveTo(p[0],p[1]);x.lineTo(p[0]+0.1,p[1]);x.stroke();e.preventDefault();};
 cv.onpointermove=function(e){if(!sigPad.drawing)return;var p=pos(e);x.lineTo(p[0],p[1]);x.stroke();e.preventDefault();};
 var end=function(){if(!sigPad.drawing)return;sigPad.drawing=false;
  var s=document.createElement('canvas');s.width=300;s.height=100;var sc=s.getContext('2d');sc.fillStyle='#fff';sc.fillRect(0,0,300,100);sc.drawImage(cv,0,0,300,100);
  draft.signature=s.toDataURL('image/png');};
 cv.onpointerup=end;cv.onpointercancel=end;}
function clearSigPad(){var cv=document.getElementById('sig-canvas');if(cv)cv.getContext('2d').clearRect(0,0,cv.width,cv.height);draft.signature='';toast('Tanda tangan dihapus');}

function vKasir(){
 var T=techs(),h='';
 if(!draft.techId&&T.length)draft.techId=T[0].id;
 if(!SYNC.url&&!PREFS.hint)h+='<section class="card row sb"><span class="small">Data baru tersimpan di perangkat ini. Hubungkan ke Google Sheets agar otomatis terbackup.</span><span class="row"><button class="btn sm pri" data-act="go-sheets">Hubungkan</button><button class="linkbtn" data-act="hint-off">Nanti</button></span></section>';
 if(lastSaved){var u=notaImgURL(lastSaved);
  h+='<section class="card stack"><div class="row sb"><h2>Nota '+esc(lastSaved.no)+' tersimpan</h2><button class="linkbtn" data-act="close-nota">Tutup</button></div>'+
  (u?'<img class="notaimg" alt="Pratinjau nota" src="'+u+'">':'<pre class="nota">'+esc(notaText(lastSaved))+'</pre>')+printBtns(lastSaved)+
  '<div class="row"><a class="btn sm pri" href="'+waLink(lastSaved,msgText(lastSaved,'terima'))+'" target="_blank" rel="noopener">Kirim bukti terima (WhatsApp)</a></div>'+
  '<span class="muted small">Pembayaran, garansi, dan status diatur di menu Nota › buka nota ini.</span></section>';}
 var cl=custList();
 h+='<section class="card stack"><div class="row sb"><h2>Nota baru</h2><span class="num muted small">'+esc(nextNo(iso(new Date())))+'</span></div>'+
 '<div class="sect">Pelanggan</div><div class="grid">'+
 '<label class="f">Nama pelanggan<input id="d-customer" list="cust-list" data-d="customer" value="'+esc(draft.customer)+'" placeholder="Ketik untuk mencari pelanggan lama" autocomplete="off"></label>'+
 '<label class="f">No. HP / WhatsApp<input id="d-phone" type="tel" inputmode="tel" data-d="phone" value="'+esc(draft.phone)+'" placeholder="08xxxxxxxxxx" autocomplete="off"></label></div>'+
 '<datalist id="cust-list">'+cl.map(function(c){return'<option value="'+esc(c.name)+'" label="'+esc(c.phone)+'"></option>';}).join('')+'</datalist>'+
 (CANPICK?'<div><button class="btn sm" data-act="pick-contact">Ambil dari kontak HP</button></div>':'')+
 '<div class="sect">Data unit</div><div class="grid">'+
 '<label class="f">Perangkat<input id="d-device" data-d="device" value="'+esc(draft.device)+'" placeholder="cth. Samsung A32" autocomplete="off"></label>'+
 '<label class="f">IMEI / Serial Number<input id="d-imei" data-d="imei" value="'+esc(draft.imei)+'" placeholder="Opsional" autocomplete="off"></label></div>'+
 '<label class="f">Keluhan<textarea id="d-complaint" data-d="complaint" placeholder="cth. LCD pecah, touchscreen tidak merespons">'+esc(draft.complaint)+'</textarea></label>'+
 '<div class="grid"><label class="f">Kunci layar<select id="d-locktype" data-d="lockType"><option value="none"'+(draft.lockType==='none'?' selected':'')+'>Tidak ada</option><option value="pass"'+(draft.lockType==='pass'?' selected':'')+'>Sandi / PIN</option><option value="pattern"'+(draft.lockType==='pattern'?' selected':'')+'>Pola</option></select></label>'+
 (draft.lockType==='pass'?'<label class="f">Sandi / PIN (internal)<input id="d-lockpass" data-d="lockPass" value="'+esc(draft.lockPass)+'" autocomplete="off"></label>':'')+'</div>'+
 (draft.lockType==='pattern'?'<div class="stack"><span class="muted small">Ketuk titik sesuai urutan pola (hanya internal).</span><div class="pat">'+[1,2,3,4,5,6,7,8,9].map(function(n){var k=draft.lockPat.indexOf(n);return'<button data-act="pat" data-v="'+n+'" aria-pressed="'+(k>=0)+'">'+(k>=0?(k+1):'•')+'</button>';}).join('')+'</div><div class="row"><span class="small">Urutan: <b class="num">'+(draft.lockPat.length?draft.lockPat.join(' → '):'belum diisi')+'</b></span><button class="linkbtn" data-act="pat-clear">Ulangi pola</button></div></div>':'')+
 '<div class="sect">Pengerjaan</div><label class="f">Teknisi<select id="d-tech" data-d="techId">'+T.map(function(s){return'<option value="'+s.id+'"'+(s.id===draft.techId?' selected':'')+'>'+esc(slabel(s))+' · bagi hasil '+pct(s.share)+' + fee '+pct(s.fee)+'</option>';}).join('')+'</select></label>'+
 draft.items.map(function(it,i){var p=it.type==='part';
  return'<div class="item"><div class="item-h"><span class="tag '+it.type+'">'+(p?'Sparepart':'Jasa')+'</span><button class="linkbtn" data-act="rm-item" data-i="'+i+'">Hapus baris</button></div><div class="item-g">'+
  '<label class="f f-name">Nama<input id="it-'+i+'-name" data-i="'+i+'" data-k="name" value="'+esc(it.name)+'" placeholder="'+(p?'cth. LCD OLED A32':'cth. Ganti LCD')+'" autocomplete="off"></label>'+
  '<label class="f">Jumlah<input id="it-'+i+'-qty" type="number" inputmode="numeric" min="1" data-i="'+i+'" data-k="qty" value="'+esc(it.qty)+'"></label>'+
  '<label class="f">Harga jual'+moneyBox('id="it-'+i+'-price" data-i="'+i+'" data-k="price"',it.price)+'</label>'+
  (p?'<label class="f">Modal'+moneyBox('id="it-'+i+'-cost" data-i="'+i+'" data-k="cost"',it.cost)+'</label>':'')+'</div></div>';}).join('')+
 '<div class="row"><button class="btn" data-act="add-jasa">+ Jasa</button><button class="btn" data-act="add-part">+ Sparepart</button></div>'+
 '<div class="sect">Tanda tangan pelanggan</div><div class="sigbox"><div class="small muted">Pelanggan menggores tanda tangan di kotak ini (bukti persetujuan biaya, risiko data, dan SOP).</div>'+
 '<canvas id="sig-canvas" class="sigcanvas"></canvas><div><button class="linkbtn" data-act="sig-clear">Hapus tanda tangan</button></div></div></section>'+
 '<section class="card" id="sum">'+sumHTML()+'</section>'+
 '<button class="btn pri" style="width:100%;padding:.85rem;font-size:1.05rem" data-act="save-tx">💾 Simpan nota'+(PREFS.autoPrint?' dan cetak':'')+'</button>'+
 '<span class="muted small" style="text-align:center;display:block">Pembayaran &amp; garansi diatur di menu Nota setelah nota tersimpan.</span>';
 return h;}

function statusBadge(t){var s=statusOf(t),c=s==='Dibatalkan'?'bad':(s==='Selesai'||s==='Diambil')?'good':s==='Diterima'?'mute':'warn';return'<span class="badge '+c+'">'+esc(STLBL[s]||s)+'</span>';}
function warrBadge(t){var w=warr(t);if(!w)return'';
 if(!w.started)return'<span class="badge mute">Garansi '+w.n+' hari, mulai setelah selesai</span>';
 if(!w.active)return'<span class="badge mute">Garansi berakhir '+fdate(w.until)+'</span>';
 return'<span class="badge '+(w.left<=7?'warn':'good')+'">Garansi s/d '+fdate(w.until)+' · sisa '+w.left+' hari</span>';}
function ln2(a,b){return'<div class="ln"><span>'+a+'</span><span>'+b+'</span></div>';}

function editSums(){var tot=0,cost=0;
 (editD.items||[]).forEach(function(it){var q=+it.qty||1;tot+=q*(+it.price||0);if(it.type==='part')cost+=q*(+it.cost||0);});
 var a=document.getElementById('edit-total'),b=document.getElementById('edit-cost'),c=document.getElementById('edit-net');
 if(a)a.textContent=rp(tot);if(b)b.textContent=rp(cost);if(c)c.textContent=rp(Math.max(0,tot-cost));}
function editPanel(t){
 var tot=0,cost=0,fin=isFin(t);
 editD.items.forEach(function(it){var q=+it.qty||1;tot+=q*(+it.price||0);if(it.type==='part')cost+=q*(+it.cost||0);});
 var h='<div class="stack">';
 editD.items.forEach(function(it,i){var p=it.type==='part';
  h+='<div class="item"><div class="item-h"><span class="tag '+it.type+'">'+(p?'Sparepart':'Jasa')+'</span><button class="linkbtn" data-act="edit-rm" data-i="'+i+'">Hapus baris</button></div><div class="item-g">'+
  '<label class="f f-name">Nama<input id="ed-'+i+'-n" data-ed="1" data-i="'+i+'" data-k="name" value="'+esc(it.name)+'" autocomplete="off"></label>'+
  '<label class="f">Jumlah<input id="ed-'+i+'-q" type="number" inputmode="numeric" min="1" data-ed="1" data-i="'+i+'" data-k="qty" value="'+esc(it.qty)+'"></label>'+
  '<label class="f">Harga jual'+moneyBox('id="ed-'+i+'-p" data-ed="1" data-i="'+i+'" data-k="price"',it.price)+'</label>'+
  (p?'<label class="f">Modal'+moneyBox('id="ed-'+i+'-c" data-ed="1" data-i="'+i+'" data-k="cost"',it.cost)+'</label>':'')+'</div></div>';});
 h+='<div class="row"><button class="btn sm" data-act="edit-add-jasa">+ Jasa</button><button class="btn sm" data-act="edit-add-part">+ Sparepart</button></div>'+
 '<div class="ledger"><div class="ln"><span>Total biaya</span><span class="num" id="edit-total">'+rp(tot)+'</span></div><div class="ln"><span>Modal sparepart</span><span class="num" id="edit-cost">'+rp(cost)+'</span></div><div class="ln tot"><span>Laba bersih (sementara)</span><span class="num" id="edit-net">'+rp(Math.max(0,tot-cost))+'</span></div></div>'+
 (fin?'<div class="box"><strong>🔒 Nota sudah selesai</strong><span class="small muted">Perubahan biaya/item wajib persetujuan Owner. Minta Owner memasukkan PIN-nya.</span><label class="f">PIN Owner<input id="ed-pin" type="password" inputmode="numeric" data-ep="1" autocomplete="off"></label></div>':'')+
 '<div class="row"><button class="btn pri sm" data-act="save-edit" data-v="'+t.id+'">💾 Simpan perubahan</button><button class="btn sm" data-act="abort-edit">Batal</button></div></div>';
 return h;}

function claimsHTML(t,w,canc){
 var id=t.id,h='';
 (t.claims||[]).forEach(function(cl,i){
  var st=cl.status||'disetujui',ed=claimEdit.id===id&&claimEdit.ci===i,ap=apprD.id===id&&apprD.ci===i;
  h+='<div class="item"><div class="row sb"><strong>Klaim '+fdate(cl.date)+'</strong><span class="badge '+(st==='disetujui'?'good':st==='ditolak'?'bad':'warn')+'">'+(st==='disetujui'?'Disetujui Owner':st==='ditolak'?'Ditolak Owner':'Menunggu persetujuan Owner')+'</span></div>';
  if(ed){
   h+='<label class="f">Keluhan pelanggan<textarea id="ce-issue" data-ce="issue">'+esc(claimEdit.issue)+'</textarea></label>'+
   '<div class="grid"><label class="f">Tindak lanjut<select id="ce-result" data-ce="result">'+CLAIMRES.map(function(r){return'<option'+(claimEdit.result===r?' selected':'')+'>'+esc(r)+'</option>';}).join('')+'</select></label>'+
   '<label class="f">Biaya ditanggung toko'+moneyBox('id="ce-cost" data-ce="cost"',claimEdit.cost)+'</label></div>'+
   '<span class="small muted">Setelah disimpan, klaim kembali berstatus "Menunggu persetujuan Owner".</span>'+
   '<div class="row"><button class="btn pri sm" data-act="save-claim-edit" data-v="'+id+'">💾 Simpan perubahan klaim</button><button class="btn sm" data-act="abort-claim-edit">Batal</button></div>';
  }else{
   h+='<span class="small">'+esc(cl.result)+(cl.cost?' · biaya toko '+rp(cl.cost):'')+'</span><span class="muted small">'+esc(cl.issue)+'</span>'+(cl.decidedAt?'<span class="muted small">Keputusan Owner: '+fdate(cl.decidedAt)+'</span>':'');
   if(ap){
    h+='<div class="box"><strong>Konfirmasi Owner: '+(apprD.mode==='ok'?'SETUJUI':'TOLAK')+' klaim</strong><label class="f">PIN Owner<input id="ap-pin" type="password" inputmode="numeric" data-ap="1" autocomplete="off"></label>'+
    '<div class="row"><button class="btn pri sm" data-act="do-acc" data-v="'+id+'">Konfirmasi</button><button class="btn sm" data-act="abort-acc">Batal</button></div></div>';
   }else{
    h+='<div class="row"><button class="btn sm" data-act="edit-claim" data-v="'+id+'" data-i="'+i+'">✏️ Edit klaim</button>'+
    (st==='menunggu'?'<a class="btn sm" href="'+waOwner(t,cl)+'" target="_blank" rel="noopener">Minta ACC via WA</a><button class="btn sm pri" data-act="ask-acc" data-v="'+id+'" data-i="'+i+'" data-m="ok">Setujui (PIN Owner)</button><button class="btn sm danger" data-act="ask-acc" data-v="'+id+'" data-i="'+i+'" data-m="no">Tolak</button>':'')+'</div>';
   }
  }
  h+='</div>';});
 if(w&&w.started&&w.active&&!canc){
  if(claimD.id===id){
   h+='<div class="box"><strong>Catat klaim garansi baru</strong><label class="f">Keluhan pelanggan<input id="cl-issue" data-cl="issue" value="'+esc(claimD.issue)+'" placeholder="cth. layar kembali bergaris" autocomplete="off"></label>'+
   '<div class="grid"><label class="f">Tindak lanjut<select id="cl-result" data-cl="result">'+CLAIMRES.map(function(r){return'<option'+(claimD.result===r?' selected':'')+'>'+esc(r)+'</option>';}).join('')+'</select></label>'+
   '<label class="f">Biaya ditanggung toko'+moneyBox('id="cl-cost" data-cl="cost"',claimD.cost)+'</label></div>'+
   '<span class="small muted">Klaim baru berstatus "Menunggu persetujuan Owner" dan belum dihitung di laporan.</span>'+
   '<div class="row"><button class="btn pri sm" data-act="save-claim" data-v="'+id+'">💾 Simpan klaim</button><button class="btn sm" data-act="abort-claim">Batal</button></div></div>';
  }else h+='<div><button class="btn sm" data-act="ask-claim" data-v="'+id+'">+ Catat klaim garansi</button></div>';}
 return h;}

function detail(t){
 var c=calc(t),stt=statusOf(t),canc=stt==='Dibatalkan',fin=isFin(t),w=warr(t),id=t.id,h='';
 h+='<div class="ledger">'+(t.device?ln2('Perangkat',esc(t.device)):'')+(t.imei?ln2('IMEI / SN','<span class="num">'+esc(t.imei)+'</span>'):'')+(t.complaint?ln2('Keluhan',esc(t.complaint)):'')+
  (t.lockType&&t.lockType!=='none'?ln2('Kunci layar <span class="muted small">(internal)</span>',esc(lockInternal(t))):'')+
  (t.phone?ln2('No. HP','<span class="num">'+esc(t.phone)+'</span>'):'')+
  ln2('Tanggal masuk',fdate(t.date))+(t.doneDate?ln2('Tanggal selesai',fdate(t.doneDate)):'')+(t.pickDate?ln2('Tanggal diambil',fdate(t.pickDate)):'')+(t.cancelAt?ln2('Tanggal batal',fdate(t.cancelAt)):'')+
  (t.signature?ln2('Tanda tangan','<img src="'+t.signature+'" class="sigimg" alt="TTD">'):'')+'</div>';
 if(editD.id===id)h+='<div class="box"><h3>Edit biaya &amp; item</h3>'+editPanel(t)+'</div>';
 else{
  h+='<div class="ledger">'+(t.items||[]).map(function(i){var q=+i.qty||1;return'<div class="ln"><span>'+esc(i.name)+' <span class="muted small">'+q+' × '+nm(i.price)+(i.type==='part'?' · modal '+nm(i.cost):'')+'</span></span><span class="num">'+rp(q*(+i.price||0))+'</span></div>';}).join('')+'</div>'+
  splitLedger(c,techName(t.techId))+
  (t.edits&&t.edits.length?'<span class="small muted">Riwayat perubahan (ACC Owner): '+t.edits.map(function(e){return fdate(e.date)+' '+rp(e.from)+' → '+rp(e.to);}).join(' · ')+'</span>':'')+
  (canc?'':'<div><button class="btn sm" data-act="ask-edit" data-v="'+id+'">'+(fin?'🔒 Edit biaya &amp; item (PIN Owner)':'✏️ Edit biaya &amp; item')+'</button></div>');}
 if(canc)h+='<div class="box"><strong class="neg">Nota dibatalkan'+(t.cancelAt?' pada '+fdate(t.cancelAt):'')+'</strong>'+(t.cancelReason?'<span class="small">Alasan: '+esc(t.cancelReason)+'</span>':'')+'<span class="muted small">Tidak masuk omzet dan bagi hasil.</span></div>';
 else{
  h+='<div class="box"><h3>Pembayaran &amp; garansi</h3><div><div class="small muted" style="margin-bottom:4px">Metode pembayaran</div><div class="seg">'+PAYS.map(function(p){return'<button data-act="set-pay" data-v="'+id+'" data-p="'+p+'" aria-pressed="'+(t.pay===p)+'">'+p+'</button>';}).join('')+'</div></div>'+
  '<div><div class="small muted" style="margin-bottom:4px">Masa garansi</div><div class="chips">'+WARRS.map(function(n){return'<button class="chip" data-act="set-warr" data-v="'+id+'" data-n="'+n+'" aria-pressed="'+((+t.warrantyDays||0)===n)+'">'+(n?n+' hari':'Tanpa garansi')+'</button>';}).join('')+'</div><span class="muted small">Pilihan langsung tersimpan otomatis. Garansi mulai berjalan saat status Selesai.</span></div></div>'+
  '<div><h3 style="margin-bottom:6px">Status pengerjaan</h3><div class="chips">'+STAT.map(function(s){return'<button class="chip" data-act="set-status" data-v="'+id+'" data-s="'+s+'" aria-pressed="'+(stt===s)+'">'+esc(STLBL[s]||s)+'</button>';}).join('')+'</div><span class="muted small">Status langsung tersimpan otomatis.</span></div>';}
 var msg=msgText(t,msgT);
 h+='<div class="box"><h3>Hubungi pelanggan</h3><select id="m-type" data-m="1">'+MSGS.map(function(m){return'<option value="'+m[0]+'"'+(msgT===m[0]?' selected':'')+'>'+m[1]+'</option>';}).join('')+'</select><pre class="nota wrapit">'+esc(msg)+'</pre><div class="row"><button class="btn sm pri" data-act="copy-msg" data-v="'+id+'">Salin pesan</button><a class="btn sm" href="'+waLink(t,msg)+'" target="_blank" rel="noopener">Kirim lewat WhatsApp</a></div>'+(t.phone?'':'<span class="muted small">Nomor HP belum diisi.</span>')+'</div>';
 h+='<div class="box"><h3>Cetak nota</h3>'+(showImg===id?'<img class="notaimg" alt="Pratinjau nota" src="'+notaImgURL(t)+'">':'')+'<div><button class="btn sm" data-act="toggle-img" data-v="'+id+'">'+(showImg===id?'Sembunyikan pratinjau':'Lihat pratinjau')+'</button></div>'+printBtns(t)+'</div>';
 if(+t.warrantyDays>0||(t.claims&&t.claims.length)){
  h+='<div class="box"><h3>Garansi &amp; klaim</h3>'+(canc?'<span class="small">Nota dibatalkan; garansi tidak berlaku.</span>':(!w||!w.started?'<span class="small">Garansi '+t.warrantyDays+' hari berlaku setelah status Selesai.</span>':'<span class="small">Garansi '+w.n+' hari: '+fdate(w.start)+' s/d '+fdate(w.until)+(w.active?' (sisa '+w.left+' hari).':' (berakhir).')+'</span>'))+claimsHTML(t,w,canc)+'</div>';}
 if(!canc){
  if(cancelD.id===id)h+='<div class="box"><strong>Batalkan nota ini?</strong><label class="f">Alasan pembatalan<textarea id="cx-reason" data-cx="1" placeholder="cth. Pelanggan batal">'+esc(cancelD.reason)+'</textarea></label><div class="row"><button class="btn sm danger" data-act="do-cancel" data-v="'+id+'">Ya, batalkan</button><button class="btn sm" data-act="abort-cancel">Kembali</button></div></div>';
  else h+='<div><button class="btn sm danger" data-act="ask-cancel" data-v="'+id+'">Batalkan nota</button></div>';}
 h+='<div><button class="btn sm danger'+(armed===id?' armed':'')+'" data-act="'+(armed===id?'del-tx':'ask-del')+'" data-v="'+id+'">'+(armed===id?'Ya, hapus permanen':'Hapus permanen')+'</button></div>';
 return h;}

function stat(l,n,c){return'<div class="stat '+c+'"><b>'+n+'</b><span>'+l+'</span></div>';}
function dayTags(t,d){var g=[];
 if(t.date===d)g.push('<span class="badge mute">Masuk</span>');
 if(isActive(t)&&isFin(t)&&finDate(t)===d)g.push('<span class="badge good">Selesai hari ini</span>');
 if(t.pickDate===d)g.push('<span class="badge good">Diambil hari ini</span>');
 if(!isActive(t)&&cancelDate(t)===d)g.push('<span class="badge bad">Batal hari ini</span>');
 return g.join('');}
function vNota(){
 var all=txs.slice(),L,h='',today=iso(new Date());
 if(flt==='hari')L=all.filter(function(t){return t.date===day||(isActive(t)&&isFin(t)&&finDate(t)===day)||t.pickDate===day||(!isActive(t)&&cancelDate(t)===day);});
 else if(flt==='proses')L=all.filter(isProc);
 else if(flt==='garansi')L=all.filter(function(t){var w=warr(t);return w&&w.started&&w.active;});
 else if(flt==='batal')L=all.filter(function(t){return !isActive(t)&&inM(cancelDate(t),month);});
 else L=all.filter(function(t){return inM(t.date,month);});
 if(flt==='garansi')L.sort(function(a,b){return warr(a).until.localeCompare(warr(b).until);});
 else L.sort(function(a,b){return(b.ts||'').localeCompare(a.ts||'');});
 var chips=[['hari','Harian'],['bulan','Bulanan'],['proses','Dalam proses'],['garansi','Garansi aktif'],['batal','Dibatalkan']];
 h+='<section class="card stack"><div class="chips">'+chips.map(function(c){return'<button class="chip" data-act="flt" data-v="'+c[0]+'" aria-pressed="'+(flt===c[0])+'">'+c[1]+'</button>';}).join('')+'</div>';
 if(flt==='hari')h+='<div class="row sb"><div class="row"><button class="btn sm" data-act="dnav" data-v="-1">‹</button><input type="date" id="dn" data-dn="1" value="'+day+'" style="width:auto"><button class="btn sm" data-act="dnav" data-v="1">›</button></div><button class="btn sm'+(day===today?'':' pri')+'" data-act="dtoday">Hari ini</button></div><strong>'+HARI[pd(day).getDay()]+', '+fdate(day)+(day===today?' · Hari ini':'')+'</strong>';
 else h+='<span class="muted small">'+(flt==='proses'||flt==='garansi'?'Semua tanggal.':'Bulan '+mlabel(month)+'.')+'</span>';
 h+='</section>';
 if(flt==='hari'){
  var o=dayStats(day),a=adminS();
  h+='<section class="card stack"><h2>Ringkasan '+(day===today?'hari ini':fdate(day))+'</h2>'+
  '<div class="stats">'+stat('Masuk',o.masuk,'')+stat('Antrian proses',o.proses,'warn')+stat('Selesai',o.selesai,'good')+stat('Diambil',o.diambil,'good')+stat('Batal',o.batal,'bad')+'</div>'+
  '<div class="ledger"><div class="ln"><span>Omzet unit selesai</span><span class="num">'+rp(o.total)+'</span></div><div class="ln"><span>Laba bersih</span><span class="num">'+rp(o.net)+'</span></div>'+
  '<div class="ln"><span>Bagi hasil teknisi</span><span class="num">'+rp(o.bh)+'</span></div><div class="ln"><span>Fee unit teknisi</span><span class="num">'+rp(o.feeAmt)+'</span></div>'+
  '<div class="ln tot"><span>Total uang teknisi</span><span class="num pos">'+rp(o.tech)+'</span></div><div class="ln tot"><span>Sisa toko</span><span class="num">'+rp(o.shop)+'</span></div></div>'+
  '<span class="small muted">Uang teknisi dihitung sekali pada tanggal unit selesai. "Antrian proses" = semua unit yang masih dikerjakan.</span></section>'+
  '<section class="card stack"><h2>Kinerja &amp; uang teknisi</h2>'+
  techs().map(function(s){var b=o.byTech[s.id]||{masuk:0,proses:0,selesai:0,diambil:0,batal:0,net:0,bh:0,feeAmt:0,tech:0};
   return'<div class="box"><div class="row sb"><strong>'+esc(s.name)+'</strong><span class="num">Hari ini: <b>'+rp(b.tech)+'</b></span></div>'+
   '<span class="small muted">Masuk '+b.masuk+' · Proses '+b.proses+' · Selesai '+b.selesai+' · Diambil '+b.diambil+' · Batal '+b.batal+'</span>'+
   '<span class="small">Laba bersih '+rp(b.net)+' → bagi hasil '+rp(b.bh)+' + fee '+rp(b.feeAmt)+'</span></div>';}).join('')+
  (a?'<div class="box"><div class="row sb"><strong>'+esc(a.name)+' (Admin)</strong><span class="num">Bonus hari ini: <b>'+rp(o.selesai*(+cfg.adminUnitFee||0)+o.net*num(cfg.adminOmzetRate)/100)+'</b></span></div><span class="small muted">'+o.selesai+' unit selesai × '+rp(cfg.adminUnitFee)+' + '+pct(cfg.adminOmzetRate)+' laba bersih (di luar gaji pokok).</span></div>':'')+'</section>';}
 if(!L.length)return h+emptyBlock(flt==='hari'?'Belum ada aktivitas pada tanggal ini':'Belum ada nota pada tampilan ini','Nota dari tab Input Data akan muncul di sini.');
 var total=0;L.forEach(function(t){if(isActive(t))total+=calc(t).total;});
 h+='<section class="card"><div class="row sb" style="margin-bottom:12px"><h2>'+L.length+' nota</h2><span class="num">'+rp(total)+'</span></div>'+
 L.map(function(t){var c=calc(t),o2=openTx===t.id;
  return'<div class="tx'+(isActive(t)?'':' cancelled')+'"><button class="tx-h" data-act="toggle-tx" data-v="'+t.id+'" aria-expanded="'+o2+'"><span class="tx-title"><strong class="num">'+esc(t.no)+'</strong> <span class="muted small">'+fdate(t.date)+' · '+esc(t.pay)+'</span><br>'+esc(t.customer||'Tanpa nama')+(t.device?' <span class="muted">· '+esc(t.device)+'</span>':'')+(t.complaint?'<br><span class="muted small">'+esc(t.complaint)+'</span>':'')+'<br><span class="muted small">Teknisi '+esc(techName(t.techId))+'</span></span><span class="num"><strong>'+rp(c.total)+'</strong></span></button><div class="row">'+statusBadge(t)+warrBadge(t)+(flt==='hari'?dayTags(t,day):'')+'</div>'+(o2?detail(t):'')+'</div>';}).join('')+'</section>';
 return h;}

function rajinRow(s,st){var k=month+'|'+s.id,on=!!(cfg.rajinCheck&&cfg.rajinCheck[k]);
 return{on:on,val:on?st.rajinPool:0,html:'<div class="ln"><span><label style="display:flex;align-items:center;gap:6px;cursor:pointer"><input type="checkbox" data-act="toggle-rajin" data-v="'+s.id+'"'+(on?' checked':'')+'> <b>Bonus Rajin ('+pct(cfg.rajinRate)+' sisa toko)</b></label><span class="small muted">Syarat: full hadir, maks 2 telat, zero rework, nota rapi.</span></span><span class="num '+(on?'pos':'muted')+'">'+(on?'+ '+rp(st.rajinPool):'Rp 0')+'</span></div>'};}
function vGaji(){
 var st=monthStats(month);
 var h='<section class="card"><h2>Gaji &amp; bagi hasil '+mlabel(month)+'</h2><p class="muted small" style="margin:6px 0 0"><b>Admin</b>: gaji pokok + bonus. <b>Teknisi</b>: tanpa gaji pokok, menerima bagi hasil + fee per unit dari nota yang <b>selesai</b> di bulan ini.</p></section>';
 cfg.staff.forEach(function(s){
  var adm=s.role==='admin',b=st.byTech[s.id]||{selesai:0,net:0,bh:0,feeAmt:0,tech:0},r=rajinRow(s,st),k=month+'|'+s.id,paid=cfg.paid&&cfg.paid[k];
  var tot=adm?(+s.base||0)+st.adminBonus+r.val:b.tech+r.val;
  h+='<section class="card"><div class="row sb"><div><h2>'+esc(s.name)+'</h2><span class="muted small">'+ROLE[s.role]+' · '+(adm?st.nSelesai+' unit selesai (toko)':b.selesai+' unit selesai')+'</span></div><span class="badge '+(paid?'good':'warn')+'">'+(paid?'Dibayar '+fdate(paid):'Belum dibayar')+'</span></div><div class="ledger" style="margin-top:10px">'+
  (adm?'<div class="ln"><span>Gaji pokok</span><span class="num">'+rp(s.base)+'</span></div><div class="ln"><span>Bonus unit ('+st.nSelesai+' × '+rp(cfg.adminUnitFee)+')</span><span class="num">'+rp(st.adminUnit)+'</span></div><div class="ln"><span>Bonus omzet ('+pct(cfg.adminOmzetRate)+' × laba bersih '+rp(st.net)+')</span><span class="num">'+rp(st.adminOmzet)+'</span></div>'
   :'<div class="ln"><span>Laba bersih unit dikerjakan</span><span class="num">'+rp(b.net)+'</span></div><div class="ln"><span>Bagi hasil ('+pct(s.share)+')</span><span class="num">'+rp(b.bh)+'</span></div><div class="ln"><span>Fee unit ('+pct(s.fee)+' dari bagian toko)</span><span class="num">'+rp(b.feeAmt)+'</span></div>')+
  r.html+'<div class="ln tot"><span>Total diterima</span><span class="num">'+rp(tot)+'</span></div></div>'+
  '<div style="margin-top:12px"><button class="btn sm" data-act="paid" data-v="'+s.id+'">'+(paid?'Batalkan tanda dibayar':'Tandai sudah dibayar')+'</button></div></section>';});
 h+='<section class="card"><div class="ledger"><div class="ln"><span>Total gaji admin + bagi hasil + bonus</span><span class="num">'+rp(st.payroll)+'</span></div><div class="ln tot"><span>Sisa bersih toko</span><span class="num '+(st.netShop<0?'neg':'pos')+'">'+rp(st.netShop)+'</span></div></div><p class="muted small" style="margin:8px 0 0">Sisa bersih = sisa toko − gaji admin − bonus admin − bonus rajin − pengeluaran − klaim garansi disetujui.</p></section>';
 return h;}

function vBiaya(){
 var st=monthStats(month),E=st.E.slice().sort(function(a,b){return b.date.localeCompare(a.date);});
 var h='<section class="card stack"><h2>Catat pengeluaran toko</h2><div class="grid"><label class="f">Tanggal<input id="e-date" type="date" data-e="date" value="'+esc(expDraft.date)+'"></label>'+
 '<label class="f">Kategori<select id="e-cat" data-e="cat">'+CATS.map(function(c){return'<option'+(c===expDraft.cat?' selected':'')+'>'+esc(c)+'</option>';}).join('')+'</select></label>'+
 '<label class="f">Jumlah'+moneyBox('id="e-amount" data-e="amount"',expDraft.amount)+'</label>'+
 '<label class="f">Keterangan<input id="e-note" data-e="note" value="'+esc(expDraft.note)+'" placeholder="cth. token listrik" autocomplete="off"></label></div>'+
 '<div><button class="btn pri" data-act="save-exp">💾 Simpan pengeluaran</button></div><p class="muted small" style="margin:0">Modal sparepart sudah dihitung dari tiap nota; gaji di tab Gaji; klaim garansi dari tab Nota.</p></section>';
 if(!E.length)return h+emptyBlock('Belum ada pengeluaran di '+mlabel(month),'Catat sewa, listrik, internet, dan kebutuhan toko lain.');
 h+='<section class="card"><div class="row sb" style="margin-bottom:8px"><h2>Pengeluaran '+mlabel(month)+'</h2><b class="num">'+rp(st.exp)+'</b></div>'+
 E.map(function(e){return'<div class="tx"><div class="row sb" style="flex-wrap:nowrap;align-items:flex-start"><span style="min-width:0"><strong>'+esc(e.cat)+'</strong> <span class="muted small">'+fdate(e.date)+'</span><br><span class="muted small">'+esc(e.note||'')+'</span></span><span class="num">'+rp(e.amount)+'</span></div><div><button class="btn sm danger'+(armed===e.id?' armed':'')+'" data-act="'+(armed===e.id?'del-exp':'ask-del')+'" data-v="'+e.id+'">'+(armed===e.id?'Ya, hapus':'Hapus')+'</button></div></div>';}).join('')+'</section>';
 return h;}

function lnx(l,v,cls,neg){return'<div class="ln '+(cls||'')+'"><span>'+l+'</span><span class="num '+(cls==='tot'&&v<0?'neg':'')+'">'+(neg&&v?'− ':'')+rp(v)+'</span></div>';}
function vLaporan(){
 var st=monthStats(month);
 if(!st.nMasuk&&!st.nSelesai&&!st.nBatal&&!st.expN&&!st.claimN)return emptyBlock('Belum ada data di '+mlabel(month),'Laporan terisi otomatis dari nota dan pengeluaran.',true);
 var fixed=st.base+st.exp+st.claimCost,cover=fixed>0?Math.max(0,Math.min(st.shop/fixed,1)):1;
 var cls=st.ratio<=.45?'good':st.ratio<=.6?'warn':'bad',lab=st.ratio<=.45?'Sehat':st.ratio<=.6?'Waspada':'Berat';
 var h='<section class="card"><h3>Laba bersih toko '+mlabel(month)+'</h3><div class="big num '+(st.netShop<0?'neg':'pos')+'" style="margin-top:6px">'+rp(st.netShop)+'</div><span class="muted small">'+st.nSelesai+' unit selesai · omzet '+rp(st.total)+'</span></section>';
 h+='<section class="card stack"><h2>Aktivitas unit</h2><div class="stats">'+stat('Masuk',st.nMasuk,'')+stat('Masih proses',st.nProses,'warn')+stat('Selesai',st.nSelesai,'good')+stat('Batal',st.nBatal,'bad')+'</div><span class="small muted">Masuk &amp; proses dari tanggal masuk; selesai dari tanggal selesai; batal dari tanggal batal.</span></section>';
 h+='<section class="card"><h2>Laba rugi</h2><div class="ledger" style="margin-top:8px">'+lnx('Penjualan jasa',st.jasa)+lnx('Penjualan sparepart',st.partRev)+lnx('Modal sparepart',st.partCost,'',true)+lnx('Laba bersih nota',st.net,'tot')+
  lnx('Bagi hasil teknisi',st.bh,'',true)+lnx('Fee unit teknisi',st.feeAmt,'',true)+lnx('Sisa toko (setelah teknisi)',st.shop,'tot')+
  lnx('Gaji pokok admin',st.base,'',true)+lnx('Bonus admin',st.adminBonus,'',true)+lnx('Bonus rajin',st.totalRajinPaid,'',true)+lnx('Pengeluaran toko',st.exp,'',true)+lnx('Klaim garansi disetujui ('+st.claimN+')',st.claimCost,'',true)+lnx('Sisa bersih toko',st.netShop,'tot')+'</div></section>';
 var rows='',tm=0,tp=0,ts=0,tb=0,tn=0,tbh=0,tf=0,tt2=0;
 techs().forEach(function(s){var b=st.byTech[s.id]||{masuk:0,proses:0,selesai:0,batal:0,net:0,bh:0,feeAmt:0,tech:0};
  tm+=b.masuk;tp+=b.proses;ts+=b.selesai;tb+=b.batal;tn+=b.net;tbh+=b.bh;tf+=b.feeAmt;tt2+=b.tech;
  rows+='<tr><td><b>'+esc(s.name)+'</b><br><span class="muted small">'+pct(s.share)+' + fee '+pct(s.fee)+'</span></td><td class="r num">'+b.masuk+'</td><td class="r num">'+b.proses+'</td><td class="r num">'+b.selesai+'</td><td class="r num">'+b.batal+'</td><td class="r num">'+nm(b.net)+'</td><td class="r num">'+nm(b.bh)+'</td><td class="r num">'+nm(b.feeAmt)+'</td><td class="r num"><b>'+nm(b.tech)+'</b></td></tr>';});
 h+='<section class="card"><h2>Per teknisi</h2><div class="tablewrap" style="margin-top:8px"><table><thead><tr><th>Teknisi</th><th class="r">Masuk</th><th class="r">Proses</th><th class="r">Selesai</th><th class="r">Batal</th><th class="r">Laba bersih</th><th class="r">Bagi hasil</th><th class="r">Fee</th><th class="r">Total</th></tr></thead><tbody>'+rows+
  '<tr class="totrow"><td>Total</td><td class="r num">'+tm+'</td><td class="r num">'+tp+'</td><td class="r num">'+ts+'</td><td class="r num">'+tb+'</td><td class="r num">'+nm(tn)+'</td><td class="r num">'+nm(tbh)+'</td><td class="r num">'+nm(tf)+'</td><td class="r num">'+nm(tt2)+'</td></tr></tbody></table></div></section>';
 var dk=Object.keys(st.days).sort().reverse();
 if(dk.length)h+='<section class="card"><h2>Rincian per hari</h2><div class="tablewrap" style="margin-top:8px"><table><thead><tr><th>Tanggal</th><th class="r">Masuk</th><th class="r">Selesai</th><th class="r">Batal</th><th class="r">Omzet</th><th class="r">Laba bersih</th><th class="r">Teknisi</th><th class="r">Toko</th></tr></thead><tbody>'+
  dk.map(function(d){var r=st.days[d];return'<tr><td>'+HARI[pd(d).getDay()].slice(0,3)+', '+fdate(d)+'</td><td class="r num">'+r.masuk+'</td><td class="r num">'+r.selesai+'</td><td class="r num">'+r.batal+'</td><td class="r num">'+nm(r.total)+'</td><td class="r num">'+nm(r.net)+'</td><td class="r num">'+nm(r.tech)+'</td><td class="r num">'+nm(r.shop)+'</td></tr>';}).join('')+'</tbody></table></div></section>';
 h+='<section class="card stack"><div class="row sb"><h2>Kesehatan biaya</h2><span class="badge '+cls+'">'+lab+'</span></div>'+
  '<div><div class="row sb small"><span>Beban tim / laba bersih nota</span><b class="num">'+Math.round(st.ratio*100)+'%</b></div><div class="bar '+(st.ratio>.6?'bad':'')+'"><i style="width:'+Math.min(st.ratio*100,100)+'%"></i></div><span class="muted small">≤45% sehat, 45–60% waspada, &gt;60% berat.</span></div>'+
  '<div><div class="row sb small"><span>Sisa toko menutup biaya tetap</span><b class="num">'+Math.round(cover*100)+'%</b></div><div class="bar '+(cover<1?'bad':'')+'"><i style="width:'+cover*100+'%"></i></div><span class="muted small">Biaya tetap '+rp(fixed)+(st.shop<fixed?' · kurang '+rp(fixed-st.shop)+' untuk impas.':' · sudah impas.')+'</span></div></section>';
 var cats=Object.keys(st.byCat).sort(function(a,b){return st.byCat[b]-st.byCat[a];});
 if(cats.length)h+='<section class="card stack"><h2>Pengeluaran per kategori</h2>'+cats.map(function(c){return'<div><div class="row sb small"><span>'+esc(c)+'</span><span class="num">'+rp(st.byCat[c])+'</span></div><div class="bar"><i style="width:'+(st.exp?st.byCat[c]/st.exp*100:0)+'%"></i></div></div>';}).join('')+'</section>';
 return h;}

function sopContent(){
 var ti=staff('t-int'),te=staff('t-exp');
 return'<div style="line-height:1.65"><h3>1. Umum &amp; kode etik</h3><ul><li>Sopan, jujur, bertanggung jawab kepada pelanggan.</li><li>Dilarang membuka, menyalin, atau menyebarkan data pribadi pelanggan (chat, kontak, foto, sandi). Pelanggaran dapat diproses hukum (UU PDP No. 27/2022).</li><li>Pola/PIN pelanggan hanya untuk uji perbaikan dan wajib dihapus setelah unit selesai.</li><li>Dilarang menerima tip di luar nota resmi.</li></ul>'+
 '<h3>2. Admin depan (Lv.1)</h3><ul><li>Terima unit, input nota, catat keluhan/IMEI, minta tanda tangan digital pelanggan.</li><li>Kirim WhatsApp: bukti terima, persetujuan biaya, unit selesai.</li><li>Terima pembayaran dan catat pengeluaran kas.</li><li>Penghasilan: <b>gaji pokok</b> + '+rp(cfg.adminUnitFee)+' per unit selesai + '+pct(cfg.adminOmzetRate)+' laba bersih bulanan.</li></ul>'+
 '<h3>3. Teknisi Interface (Lv.2)</h3><ul><li>LCD, baterai, konektor charger, speaker, mic, flexibel, flashing standar. Wajib QC lengkap sebelum serah ke admin.</li><li>Penghasilan: <b>tanpa gaji pokok</b>, bagi hasil '+pct(ti?ti.share:30)+' laba bersih + fee '+pct(ti?ti.fee:2)+' dari bagian toko per unit selesai.</li></ul>'+
 '<h3>4. Teknisi Expert (Lv.3)</h3><ul><li>Mati total, short, kena cairan, reball, jumper, ganti IC. Wajib diagnosa tertulis dan persetujuan biaya pelanggan sebelum eksekusi.</li><li>Penghasilan: <b>tanpa gaji pokok</b>, bagi hasil '+pct(te?te.share:40)+' laba bersih + fee '+pct(te?te.fee:2)+' dari bagian toko per unit selesai.</li></ul>'+
 '<h3>5. Lupa pola / PIN</h3><ul><li>Wajib verifikasi pemilik: KTP/SIM sesuai nama nota, atau kotak/nota pembelian. Tanpa bukti kepemilikan: TOLAK.</li><li>Pelanggan wajib tanda tangan digital: paham reset dapat menghapus seluruh data.</li><li>Dilarang menebak pola berkali-kali. Hapus catatan pola setelah selesai.</li></ul>'+
 '<h3>6. Lupa akun Google (FRP)</h3><ul><li>Toko TIDAK melayani bypass/pembobolan akun Google (FRP) dan TIDAK login ke akun pelanggan (UU ITE Pasal 30).</li><li>Teknisi hanya membantu pemilik sah memulihkan akun lewat prosedur resmi Google.</li><li>Reset pabrik tidak menghapus FRP: pelanggan wajib login dengan akun aslinya.</li></ul>'+
 '<h3>7. Klaim garansi &amp; perubahan nota (persetujuan Owner)</h3><ul><li>Klaim garansi baru berstatus "Menunggu persetujuan Owner". Biaya klaim masuk laporan setelah Owner menyetujui dengan PIN.</li><li>Klaim yang diedit kembali ke status menunggu dan butuh ACC ulang.</li><li>Nota Selesai/Diambil hanya boleh diubah biaya/itemnya dengan PIN Owner. Semua perubahan tercatat di riwayat nota.</li></ul>'+
 '<h3>8. Bonus rajin ('+pct(cfg.rajinRate)+' sisa toko)</h3><ul><li>Dicentang manual oleh Owner di menu Gaji bila semua syarat terpenuhi: full hadir (izin maks 1x), telat maks 2x, zero rework, tidak ada nota menggantung &gt;7 hari.</li></ul>'+
 '<h3>9. Kebersihan toko</h3><ul><li>Pagi: sapu, lap meja &amp; etalase. Siang: pel, rapikan ruang tunggu. Tutup: buang sampah, kunci laci kasir.</li><li>Dilarang makan/minum di area servis &amp; kasir, dilarang merokok di dalam toko.</li></ul>'+
 '<h3>10. Sanksi</h3><ul><li>Menyebarkan data pelanggan: SP3 + proses hukum. Tip tanpa nota: SP1 + pengembalian. Kerusakan karena kelalaian: potong bagi hasil sesuai nilai kerusakan.</li></ul>'+
 '<div class="row" style="margin-top:12px"><button class="btn pri sm" data-act="sop-print">Cetak SOP</button><button class="btn sm" data-act="sop-setujui">Saya paham &amp; menyetujui</button></div></div>';}

function aturBody(){
 var h='';
 if(aturTab==='toko'){
  var ex=calc({items:[{type:'jasa',qty:1,price:260000}],share:30,fee:2}),ex2=calc({items:[{type:'jasa',qty:1,price:260000}],share:40,fee:2});
  h+='<section class="card stack"><h2>Toko</h2><div class="grid"><label class="f">Nama toko<input id="c-shop" data-c="shop" value="'+esc(cfg.shop)+'" autocomplete="off"></label><label class="f">Telepon / WA toko<input id="c-phone" type="tel" data-c="phone" value="'+esc(cfg.phone)+'" placeholder="08xxxxxxxxxx" autocomplete="off"></label></div>'+
  '<label class="f">Alamat<input id="c-addr" data-c="addr" value="'+esc(cfg.addr)+'" placeholder="Alamat untuk kepala nota" autocomplete="off"></label>'+
  '<label class="f">Garansi standar<select id="c-wd" data-c="warrantyDays">'+WARRS.map(function(n){return'<option value="'+n+'"'+(+cfg.warrantyDays===n?' selected':'')+'>'+(n?n+' hari':'Tanpa garansi')+'</option>';}).join('')+'</select></label>'+
  '<label class="f">Ketentuan garansi (dicetak di nota)<textarea id="c-terms" data-c="terms">'+esc(cfg.terms)+'</textarea></label></section>'+
  '<section class="card stack"><div class="row sb"><h2>Owner &amp; persetujuan</h2><span class="badge '+(cfg.ownerPinH?'good':'warn')+'">'+(cfg.ownerPinH?'PIN sudah diatur':'PIN belum diatur')+'</span></div>'+
  '<p class="muted small" style="margin:0">PIN dipakai untuk menyetujui klaim garansi dan mengubah nota yang sudah selesai.</p><div class="grid">'+
  '<label class="f">WhatsApp Owner (untuk minta ACC)<input id="c-ophone" type="tel" data-c="ownerPhone" value="'+esc(cfg.ownerPhone)+'" placeholder="08xxxxxxxxxx" autocomplete="off"></label>'+
  '<label class="f">'+(cfg.ownerPinH?'Ganti PIN Owner':'Buat PIN Owner')+' (4–8 angka)<input id="c-opin" type="password" inputmode="numeric" data-c="ownerPin" placeholder="••••" autocomplete="new-password"></label></div></section>'+
  '<section class="card stack"><h2>Rumus bagi hasil teknisi</h2><div class="box small">Laba bersih = total nota − modal sparepart<br>Bagi hasil = laba bersih × % teknisi<br>Bagian toko awal = laba bersih − bagi hasil<br>Fee unit = bagian toko awal × % fee<br><b>Total teknisi = bagi hasil + fee unit</b><br><b>Sisa toko = bagian toko awal − fee unit</b></div>'+
  '<span class="small muted">Contoh laba bersih Rp 260.000 · Interface 30% + fee 2%: teknisi '+rp(ex.tech)+', toko '+rp(ex.shop)+' · Expert 40% + fee 2%: teknisi '+rp(ex2.tech)+', toko '+rp(ex2.shop)+'.</span></section>';
  admins().forEach(function(s){
   h+='<section class="card stack"><h2>'+ROLE.admin+' — gaji bulanan</h2><div class="grid"><label class="f">Nama<input id="s-'+s.id+'-name" data-s="'+s.id+'" data-f="name" value="'+esc(s.name)+'" autocomplete="off"></label>'+
   '<label class="f">Gaji pokok'+moneyBox('id="s-'+s.id+'-base" data-s="'+s.id+'" data-f="base"',s.base)+'</label>'+
   '<label class="f">Bonus per unit selesai'+moneyBox('id="c-admfee" data-c="adminUnitFee"',cfg.adminUnitFee)+'</label>'+
   '<label class="f">Bonus omzet (% laba bersih)<input id="c-admomzet" type="number" step="0.1" min="0" data-c="adminOmzetRate" value="'+num(cfg.adminOmzetRate)+'"></label></div>'+
   '<span class="muted small">Isi 0 bila admin tidak diberi bonus.</span></section>';});
  techs().forEach(function(s){
   h+='<section class="card stack"><h2>'+esc(ROLE[s.role])+' — bagi hasil (tanpa gaji pokok)</h2><div class="grid"><label class="f">Nama<input id="s-'+s.id+'-name" data-s="'+s.id+'" data-f="name" value="'+esc(s.name)+'" autocomplete="off"></label>'+
   '<label class="f">Bagi hasil (% laba bersih)<input id="s-'+s.id+'-share" type="number" step="0.1" min="0" max="100" data-s="'+s.id+'" data-f="share" value="'+num(s.share)+'"></label>'+
   '<label class="f">Fee per unit (% bagian toko)<input id="s-'+s.id+'-fee" type="number" step="0.01" min="0" max="100" data-s="'+s.id+'" data-f="fee" value="'+num(s.fee)+'"></label></div>'+
   '<span class="muted small">Fee bisa diisi 1, 2, atau 3 (desimal boleh, cth 0,67). Perubahan berlaku untuk nota baru; nota lama memakai % saat dibuat.</span></section>';});
  h+='<section class="card stack"><h2>Bonus rajin</h2><label class="f">Bonus rajin (% sisa toko, per orang yang dicentang)<input id="c-rajin" type="number" step="0.1" min="0" data-c="rajinRate" value="'+num(cfg.rajinRate)+'"></label></section>';
 }
 if(aturTab==='tampilan'){
  h+='<section class="card stack"><h2>Tema</h2><div class="thms"><button class="thm" data-act="theme" data-v="auto" aria-pressed="'+(PREFS.theme==='auto')+'"><div class="pv" style="background:linear-gradient(90deg,#EBEFEA 50%,#0F1613 50%);color:#888"><b>Aa</b><i style="background:#0B7A5A"></i></div><b class="small">Otomatis</b></button>'+
  THEMES.map(function(t){return'<button class="thm" data-act="theme" data-v="'+t[0]+'" aria-pressed="'+(PREFS.theme===t[0])+'"><div class="pv" style="background:'+t[2]+';color:'+t[3]+'"><b>Aa 123</b><i style="background:'+t[4]+'"></i></div><b class="small">'+t[1]+'</b></button>';}).join('')+'</div></section>'+
  '<section class="card stack"><h2>Ukuran tulisan</h2><div class="seg">'+[['s','Kecil'],['m','Sedang'],['l','Besar']].map(function(f){return'<button data-act="fsize" data-v="'+f[0]+'" aria-pressed="'+(PREFS.fs===f[0])+'">'+f[1]+'</button>';}).join('')+'</div></section>'+
  '<section class="card stack"><h2>Pasang sebagai aplikasi</h2><p class="small" style="margin:0">'+(installEv?'Aplikasi dapat dipasang di layar utama.':'Di Chrome Android: menu ⋮ › Pasang aplikasi.')+'</p>'+(installEv?'<div><button class="btn pri" data-act="install">Pasang aplikasi</button></div>':'')+'</section>';}
 if(aturTab==='printer'){
  h+='<section class="card stack"><h2>Printer thermal</h2><div class="grid"><label class="f">Lebar kertas<select id="p-paper" data-p="paper"><option value="32"'+(+PREFS.paper===32?' selected':'')+'>58 mm</option><option value="48"'+(+PREFS.paper===48?' selected':'')+'>80 mm</option></select></label>'+
  '<label class="f">Mode cetak<select id="p-mode" data-p="pmode"><option value="img"'+(PREFS.pmode==='img'?' selected':'')+'>Gambar (terbaik)</option><option value="text"'+(PREFS.pmode==='text'?' selected':'')+'>Teks (cepat)</option></select></label>'+
  '<label class="f">Kecepatan kirim<select id="p-chunk" data-p="chunk"><option value="20"'+(+PREFS.chunk===20?' selected':'')+'>Aman</option><option value="100"'+(+PREFS.chunk===100?' selected':'')+'>Normal</option><option value="180"'+(+PREFS.chunk===180?' selected':'')+'>Cepat</option></select></label>'+
  '<label class="f">Cetak otomatis<select id="p-auto" data-p="autoPrint"><option value="0"'+(!PREFS.autoPrint?' selected':'')+'>Mati</option><option value="1"'+(PREFS.autoPrint?' selected':'')+'>Hidup saat nota disimpan</option></select></label></div>'+
  '<div class="box"><div class="row sb"><strong>'+(BT.ch?esc(BT.name)+' terhubung':(PREFS.btName?'Terakhir: '+esc(PREFS.btName):'Belum ada printer'))+'</strong><span class="badge '+(BT.ch?'good':'mute')+'">'+(BT.ch?'Tersambung':'Terputus')+'</span></div>'+
  (btSupported()?'<div class="row"><button class="btn pri sm" data-act="bt-connect">'+(BT.ch?'Ganti printer':'Hubungkan printer')+'</button><button class="btn sm" data-act="bt-test">Tes cetak</button>'+(BT.ch?'<button class="btn sm" data-act="bt-off">Putuskan</button>':'')+'</div>':'<span class="small neg">Browser tidak mendukung Bluetooth langsung. Gunakan Chrome Android (HTTPS) atau tombol Bagikan gambar nota.</span>')+'</div>'+
  '<p class="muted small" style="margin:0">Cetak langsung untuk printer Bluetooth BLE. Printer Bluetooth Classic: Bagikan gambar nota ke aplikasi seperti RawBT.</p></section>';}
 if(aturTab==='sheets'){
  var sl=syncLabel();
  h+='<section class="card stack"><h2>Google Sheets</h2><p class="small muted" style="margin:0">Data nota, pengeluaran, dan pengaturan otomatis dikirim ke Google Sheet Anda.</p>'+
  '<label class="f">Tautan Web App (Apps Script)<input id="sy-url" data-sy="url" value="'+esc(SYNC.url)+'" placeholder="https://script.google.com/macros/s/…/exec" autocomplete="off" inputmode="url"></label>'+
  '<label class="f">Kode rahasia<input id="sy-token" data-sy="token" type="password" value="'+esc(SYNC.token)+'" autocomplete="off"></label>'+
  '<div class="box"><div class="row sb"><strong>Status</strong><span class="badge '+(sl.c==='ok'?'good':sl.c==='err'?'bad':'mute')+'">'+esc(sl.t)+'</span></div><span class="small muted">'+pendingCount()+' data menunggu'+(SYNC.err?' · kendala: '+esc(SYNC.err):'')+'</span></div>'+
  '<div class="row"><button class="btn pri" data-act="sy-test">Hubungkan &amp; uji</button><button class="btn" data-act="sy-now">Sinkronkan sekarang</button></div>'+
  '<div class="row"><button class="btn sm" data-act="sy-pull">Ambil ulang semua dari Sheet</button><button class="btn sm danger" data-act="sy-off">Putuskan</button></div></section>';}
 if(aturTab==='data'){
  h+='<section class="card stack"><h2>Cadangan &amp; ekspor</h2><div class="row"><button class="btn" data-act="exp-tx">Unduh nota bulan ini (CSV)</button><button class="btn" data-act="exp-exp">Unduh pengeluaran (CSV)</button></div>'+
  '<div class="row"><button class="btn" data-act="backup">Unduh cadangan (.json)</button><label class="btn" for="restore-file" style="cursor:pointer">Pulihkan dari cadangan</label><input id="restore-file" type="file" accept=".json,application/json" hidden></div>'+
  '<p class="muted small" style="margin:0">Cadangan berisi seluruh data termasuk sandi/pola layar pelanggan. Simpan di tempat aman.</p></section>'+
  '<section class="card stack"><h2>Data contoh</h2><div class="row"><button class="btn" data-act="sample">Isi data contoh</button><button class="btn danger" data-act="rm-sample">Hapus data contoh</button></div></section>';}
 if(aturTab==='sop')h+='<section class="card stack"><h2>SOP &amp; tata tertib '+esc(cfg.shop)+'</h2><span class="badge '+(PREFS.sopSetujui?'good':'warn')+'">'+(PREFS.sopSetujui?'SOP sudah disetujui di perangkat ini':'Belum menyetujui SOP')+'</span>'+sopContent()+'</section>';
 return h;}
function vAtur(){
 var tabs=[['toko','Toko & tarif'],['tampilan','Tampilan'],['printer','Printer'],['sheets','Google Sheets'],['data','Data'],['sop','SOP']];
 return'<section class="card"><div class="chips">'+tabs.map(function(t){return'<button class="chip" data-act="atur" data-v="'+t[0]+'" aria-pressed="'+(aturTab===t[0])+'">'+esc(t[1])+'</button>';}).join('')+'</div><p class="muted small" style="margin:8px 0 0">Semua isian di menu Atur tersimpan otomatis begitu diubah.</p></section>'+aturBody();}

function copy(text,ok){var f=function(){toast('Penyalinan gagal. Salin manual.');};try{navigator.clipboard.writeText(text).then(function(){toast(ok||'Berhasil disalin');},f);}catch(e){f();}}
function csvRow(a){return a.map(function(v){return'"'+String(v==null?'':v).replace(/"/g,'""')+'"';}).join(',');}
function download(name,data,type){try{var b=(data instanceof Blob)?data:new Blob([data],{type:type||'text/plain'});var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},2000);toast('Berkas diunduh: '+name);}catch(e){toast('Unduhan gagal.');}}
function dlImg(t){preSig(t).then(function(){var cv;try{cv=drawNota(t);}catch(e){toast('Gambar nota gagal dibuat.');return;}cv.toBlob(function(b){if(!b){toast('Gambar nota gagal dibuat.');return;}download('nota-'+t.no+'.png',b);},'image/png');});}
function shareImg(t){preSig(t).then(function(){var cv;try{cv=drawNota(t);}catch(e){toast('Gambar nota gagal dibuat.');return;}
 cv.toBlob(function(b){if(!b){toast('Gambar nota gagal dibuat.');return;}
  var f;try{f=new File([b],'nota-'+t.no+'.png',{type:'image/png'});}catch(e){download('nota-'+t.no+'.png',b);return;}
  if(navigator.canShare&&navigator.canShare({files:[f]})){navigator.share({files:[f],title:'Nota '+t.no}).catch(function(e){if(e&&e.name!=='AbortError')toast('Berbagi gagal.');});}
  else download('nota-'+t.no+'.png',b);},'image/png');});}
function saveTx(){
 var items=draft.items.filter(function(i){return String(i.name).trim()&&(+i.price||0)>0;}).map(function(i){return{type:i.type,name:String(i.name).trim(),qty:Math.max(1,+i.qty||1),price:+i.price||0,cost:i.type==='part'?(+i.cost||0):0};});
 if(!draft.device.trim()){toast('Mohon isi nama perangkat.');return;}
 if(!items.length){toast('Isi minimal satu baris dengan nama dan harga.');return;}
 if(!draft.techId){toast('Pilih teknisi terlebih dahulu.');return;}
 var d=iso(new Date()),s=staff(draft.techId);month=d.slice(0,7);day=d;dayAuto=true;
 var t={id:uid(),no:nextNo(d),ts:new Date().toISOString(),date:d,customer:draft.customer.trim(),phone:draft.phone.trim(),device:draft.device.trim(),imei:draft.imei.trim(),complaint:draft.complaint.trim(),
  lockType:draft.lockType,lockPass:draft.lockType==='pass'?draft.lockPass:'',lockPat:draft.lockType==='pattern'?draft.lockPat:[],signature:draft.signature||'',
  techId:draft.techId,share:s?num(s.share):0,fee:s?num(s.fee):0,pay:draft.pay||'Tunai',items:items,status:'Diterima',warrantyDays:+cfg.warrantyDays||0,claims:[]};
 put('tx',t);t=DOCS['tx/'+t.id];lastSaved=t;var tid=draft.techId;draft=newDraft();draft.techId=tid;render();window.scrollTo(0,0);
 if(PREFS.autoPrint&&btSupported())printTx(t);else toast('Nota tersimpan.');}
function sampleData(){
 var now=new Date(),m=iso(now).slice(0,7),today=now.getDate();
 var J=function(n,p){return{type:'jasa',name:n,qty:1,price:p,cost:0};},P=function(n,p,c){return{type:'part',name:n,qty:1,price:p,cost:c};};
 var defs=[[1,'Budi','081234567801','Samsung A32','LCD pecah','t-exp',[J('Ganti LCD',150000),P('LCD OLED A32',420000,310000)],'Tunai','Diambil'],
  [2,'Sari','081234567802','Oppo A15','Baterai drop','t-int',[J('Ganti baterai',60000),P('Baterai A15',95000,60000)],'QRIS','Diambil'],
  [3,'Dedi','081234567803','Laptop Asus X441','Mati total','t-exp',[J('Servis mainboard',350000)],'Transfer','Selesai'],
  [5,'Rina','081234567804','iPhone 11','Charging error','t-exp',[J('Ganti konektor charger',180000),P('Flex charger',120000,70000)],'Tunai','Dikerjakan'],
  [6,'Agus','081234567805','Xiaomi Redmi 9','Bootloop','t-int',[J('Flash ulang',75000)],'Tunai','Menunggu konfirmasi']];
 defs.forEach(function(x){var dd=Math.min(x[0],today),d=m+'-'+(dd<10?'0':'')+dd,s=staff(x[5]);
  var t={id:uid(),no:nextNo(d),ts:d+'T10:'+(10+dd)+':00.000Z',date:d,customer:x[1],phone:x[2],device:x[3],complaint:x[4],imei:'',lockType:'none',lockPass:'',lockPat:[],signature:'',techId:x[5],share:s?num(s.share):0,fee:s?num(s.fee):0,pay:x[7],items:x[6],status:x[8],warrantyDays:30,claims:[],sample:true};
  if(x[8]==='Selesai'||x[8]==='Diambil')t.doneDate=d;if(x[8]==='Diambil')t.pickDate=d;put('tx',t);});
 [[1,'Sewa tempat',1500000,'Sewa kios'],[2,'Listrik & air',320000,'Token listrik']].forEach(function(x){var dd=Math.min(x[0],today);put('exp',{id:uid(),date:m+'-'+(dd<10?'0':'')+dd,cat:x[1],amount:x[2],note:x[3],sample:true});});
 month=m;toast('Data contoh ditambahkan');render();}
function pickContact(){try{navigator.contacts.select(['name','tel'],{multiple:false}).then(function(r){if(r&&r[0]){var c=r[0];if(c.name&&c.name[0])draft.customer=c.name[0];if(c.tel&&c.tel[0])draft.phone=c.tel[0];render();toast('Kontak dimasukkan');}}).catch(function(){toast('Akses kontak tidak tersedia.');});}catch(e){toast('Akses kontak tidak tersedia.');}}
function exportAll(){var o={v:1,exported:new Date().toISOString(),docs:[]};Object.keys(DOCS).forEach(function(k){if(!DOCS[k].deleted)o.docs.push({k:k,v:DOCS[k]});});return JSON.stringify(o);}
function restoreFile(file){var fr=new FileReader();fr.onload=function(){try{var o=JSON.parse(fr.result);if(!o||!o.docs)throw 0;var n=0;
 o.docs.forEach(function(d){if(!d||!d.k||!d.v)return;DOCS[d.k]=d.v;d.v.updated=Date.now();persist(d.k);mark(d.k);n++;});rebuild();render();toast('Cadangan dipulihkan: '+n+' data.');}catch(e){toast('Berkas cadangan tidak dapat dibaca.');}};fr.readAsText(file);}

function act(a,el){
 var v=el.dataset.v,i=+el.dataset.i,t,k;
 if(a==='tab'){tab=v;armed=null;if(v==='riwayat'&&dayAuto)day=iso(new Date());render();window.scrollTo(0,0);}
 else if(a==='go-sheets'){tab='atur';aturTab='sheets';render();window.scrollTo(0,0);}
 else if(a==='hint-off'){PREFS.hint=true;savePrefs();render();}
 else if(a==='atur'){aturTab=v;render();}
 else if(a==='mon'){var p=month.split('-'),d=new Date(+p[0],+p[1]-1+(+v),1);month=iso(d).slice(0,7);openTx=null;render();}
 else if(a==='flt'){flt=v;openTx=null;armed=null;render();}
 else if(a==='dnav'){day=addDays(day,+v);dayAuto=(day===iso(new Date()));openTx=null;render();}
 else if(a==='dtoday'){day=iso(new Date());dayAuto=true;openTx=null;render();}
 else if(a==='theme'){PREFS.theme=v;savePrefs();applyTheme();render();}
 else if(a==='fsize'){PREFS.fs=v;savePrefs();applyTheme();render();}
 else if(a==='install'){if(installEv){installEv.prompt();installEv=null;render();}}
 else if(a==='pick-contact')pickContact();
 else if(a==='pat'){var n=+v;if(draft.lockPat.indexOf(n)<0){draft.lockPat.push(n);render();}}
 else if(a==='pat-clear'){draft.lockPat=[];render();}
 else if(a==='sig-clear')clearSigPad();
 else if(a==='add-jasa'){draft.items.push({type:'jasa',name:'',qty:1,price:''});render();}
 else if(a==='add-part'){draft.items.push({type:'part',name:'',qty:1,price:'',cost:''});render();}
 else if(a==='rm-item'){draft.items.splice(i,1);if(!draft.items.length)draft.items.push({type:'jasa',name:'',qty:1,price:''});render();}
 else if(a==='save-tx')saveTx();
 else if(a==='close-nota'){lastSaved=null;render();}
 else if(a==='print'){t=findTx(v);if(t)printTx(t);}
 else if(a==='share-img'){t=findTx(v);if(t)shareImg(t);}
 else if(a==='dl-img'){t=findTx(v);if(t)dlImg(t);}
 else if(a==='toggle-img'){showImg=showImg===v?null:v;render();}
 else if(a==='copy-tx'){t=findTx(v);if(t)copy(notaText(t),'Teks nota disalin.');}
 else if(a==='copy-msg'){t=findTx(v);if(t)copy(msgText(t,msgT),'Pesan disalin');}
 else if(a==='bt-connect'){if(!btSupported())return;btConnect().then(function(){toast('Printer terhubung: '+BT.name);render();}).catch(function(e){toast(btErr(e));});}
 else if(a==='bt-test')testPrint();
 else if(a==='bt-off'){try{if(BT.dev&&BT.dev.gatt.connected)BT.dev.gatt.disconnect();}catch(e){}BT.ch=null;render();}
 else if(a==='toggle-tx'){openTx=openTx===v?null:v;armed=null;showImg=null;editD={id:null,items:null,pin:''};cancelD={id:null,reason:''};claimD.id=null;claimEdit={id:null,ci:-1};apprD={id:null,ci:-1,mode:'ok',pin:''};
  t=findTx(v);if(t&&openTx)msgT=isActive(t)?(STMSG[statusOf(t)]||'terima'):'batal';render();}
 else if(a==='set-status'){t=findTx(v);if(!t)return;var s=el.dataset.s,td=iso(new Date());t.status=s;
  if(s==='Selesai'||s==='Diambil'){if(!t.doneDate)t.doneDate=td;}
  if(s==='Diambil'){if(!t.pickDate)t.pickDate=td;}else delete t.pickDate;
  if(PROSES.indexOf(s)>=0)delete t.doneDate;
  msgT=STMSG[s]||msgT;put('tx',t);render();toast('Status tersimpan: "'+(STLBL[s]||s)+'".');}
 else if(a==='set-pay'){t=findTx(v);if(!t)return;t.pay=el.dataset.p||'Tunai';put('tx',t);render();toast('Pembayaran tersimpan: '+t.pay+'.');}
 else if(a==='set-warr'){t=findTx(v);if(!t)return;t.warrantyDays=+el.dataset.n||0;put('tx',t);render();toast(t.warrantyDays?'Garansi tersimpan: '+t.warrantyDays+' hari.':'Garansi dihapus dari nota ini.');}
 else if(a==='ask-edit'){t=findTx(v);if(!t||!isActive(t))return;editD={id:v,items:JSON.parse(JSON.stringify(t.items||[])),pin:''};render();}
 else if(a==='abort-edit'){editD={id:null,items:null,pin:''};render();}
 else if(a==='edit-add-jasa'){if(editD.items){editD.items.push({type:'jasa',name:'',qty:1,price:''});render();}}
 else if(a==='edit-add-part'){if(editD.items){editD.items.push({type:'part',name:'',qty:1,price:'',cost:0});render();}}
 else if(a==='edit-rm'){if(editD.items){editD.items.splice(i,1);if(!editD.items.length)editD.items.push({type:'jasa',name:'',qty:1,price:''});render();}}
 else if(a==='save-edit'){t=findTx(v);if(!t||editD.id!==v||!editD.items)return;
  var nIt=editD.items.filter(function(x){return String(x.name||'').trim()&&(+x.price||0)>0;}).map(function(x){return{type:x.type,name:String(x.name).trim(),qty:Math.max(1,+x.qty||1),price:+x.price||0,cost:x.type==='part'?(+x.cost||0):0};});
  if(!nIt.length){toast('Minimal satu baris dengan nama dan harga.');return;}
  var fin=isFin(t);
  if(fin){if(!cfg.ownerPinH){toast('PIN Owner belum diatur. Atur di Atur › Toko & tarif.');return;}
   if(!ownerOK(editD.pin)){toast('PIN Owner salah. Perubahan ditolak.');return;}}
  var before=calc(t).total;t.items=nIt;
  if(fin)t.edits=(t.edits||[]).concat([{date:iso(new Date()),from:before,to:calc(t).total}]);
  put('tx',t);editD={id:null,items:null,pin:''};render();toast(fin?'Perubahan disimpan (ACC Owner).':'Biaya & item nota tersimpan.');}
 else if(a==='ask-cancel'){cancelD={id:v,reason:''};render();}
 else if(a==='abort-cancel'){cancelD={id:null,reason:''};render();}
 else if(a==='do-cancel'){t=findTx(v);if(!t)return;var rs=cancelD.reason.trim();if(!rs){toast('Mohon isi alasan pembatalan.');return;}
  t.status='Dibatalkan';t.cancelReason=rs;t.cancelAt=iso(new Date());delete t.pickDate;put('tx',t);cancelD={id:null,reason:''};msgT='batal';render();toast('Nota dibatalkan.');}
 else if(a==='ask-claim'){claimD={id:v,issue:'',result:CLAIMRES[0],cost:0};render();}
 else if(a==='abort-claim'){claimD.id=null;render();}
 else if(a==='save-claim'){t=findTx(v);if(!t)return;var w=warr(t);
  if(!w||!w.active){toast('Masa garansi nota ini sudah berakhir.');return;}
  if(!String(claimD.issue).trim()){toast('Isi keluhan pelanggan terlebih dahulu.');return;}
  t.claims=(t.claims||[]).concat([{id:uid(),date:iso(new Date()),issue:String(claimD.issue).trim(),result:claimD.result,cost:+claimD.cost||0,status:'menunggu'}]);
  put('tx',t);claimD.id=null;render();toast('Klaim tersimpan. Menunggu persetujuan Owner.');}
 else if(a==='edit-claim'){t=findTx(v);if(!t||!t.claims||!t.claims[i])return;var cc=t.claims[i];claimEdit={id:v,ci:i,issue:cc.issue,result:cc.result,cost:cc.cost||0};apprD={id:null,ci:-1,mode:'ok',pin:''};render();}
 else if(a==='abort-claim-edit'){claimEdit={id:null,ci:-1};render();}
 else if(a==='save-claim-edit'){t=findTx(v);if(!t||claimEdit.id!==v||!t.claims[claimEdit.ci])return;
  if(!String(claimEdit.issue).trim()){toast('Keluhan tidak boleh kosong.');return;}
  var cl2=t.claims[claimEdit.ci];cl2.issue=String(claimEdit.issue).trim();cl2.result=claimEdit.result;cl2.cost=+claimEdit.cost||0;cl2.status='menunggu';cl2.decidedAt='';cl2.edited=iso(new Date());
  put('tx',t);claimEdit={id:null,ci:-1};render();toast('Klaim tersimpan. Menunggu persetujuan Owner.');}
 else if(a==='ask-acc'){apprD={id:v,ci:i,mode:el.dataset.m||'ok',pin:''};claimEdit={id:null,ci:-1};render();}
 else if(a==='abort-acc'){apprD={id:null,ci:-1,mode:'ok',pin:''};render();}
 else if(a==='do-acc'){t=findTx(v);if(!t||apprD.id!==v||!t.claims[apprD.ci])return;
  if(!cfg.ownerPinH){toast('PIN Owner belum diatur. Atur di Atur › Toko & tarif.');return;}
  if(!ownerOK(apprD.pin)){toast('PIN Owner salah.');return;}
  var cl3=t.claims[apprD.ci];cl3.status=apprD.mode==='ok'?'disetujui':'ditolak';cl3.decidedAt=iso(new Date());
  put('tx',t);var md=apprD.mode;apprD={id:null,ci:-1,mode:'ok',pin:''};render();toast(md==='ok'?'Klaim disetujui Owner.':'Klaim ditolak Owner.');}
 else if(a==='ask-del'){armed=v;render();}
 else if(a==='del-tx'){armed=null;openTx=null;drop('tx',v);render();toast('Nota dihapus permanen');}
 else if(a==='del-exp'){armed=null;drop('exp',v);render();toast('Pengeluaran dihapus');}
 else if(a==='toggle-rajin'){cfg.rajinCheck=cfg.rajinCheck||{};k=month+'|'+v;cfg.rajinCheck[k]=!cfg.rajinCheck[k];saveCfg();render();toast(cfg.rajinCheck[k]?'Bonus rajin diaktifkan.':'Bonus rajin dibatalkan.');}
 else if(a==='paid'){cfg.paid=cfg.paid||{};k=month+'|'+v;if(cfg.paid[k])delete cfg.paid[k];else cfg.paid[k]=iso(new Date());saveCfg();render();}
 else if(a==='save-exp'){var amt=+expDraft.amount||0;if(amt<=0||!expDraft.date){toast('Isi tanggal dan jumlah pengeluaran.');return;}
  put('exp',{id:uid(),date:expDraft.date,cat:expDraft.cat,amount:amt,note:String(expDraft.note).trim()});
  var keep={date:expDraft.date,cat:expDraft.cat};expDraft=newExp();expDraft.date=keep.date;expDraft.cat=keep.cat;month=keep.date.slice(0,7);render();toast('Pengeluaran tersimpan');}
 else if(a==='sample')sampleData();
 else if(a==='rm-sample'){txs.filter(function(x){return x.sample;}).forEach(function(x){drop('tx',x.id);});exps.filter(function(x){return x.sample;}).forEach(function(x){drop('exp',x.id);});render();toast('Data contoh dihapus');}
 else if(a==='backup')download('cadangan-kasir-'+iso(new Date())+'.json',exportAll(),'application/json');
 else if(a==='sy-test'){
  if(!/^https:\/\/script\.google\.com\//.test(SYNC.url)){toast('Tautan harus diawali https://script.google.com/');return;}
  if(!SYNC.token){toast('Isi kode rahasia.');return;}
  toast('Menguji koneksi…');
  api({action:'ping'}).then(function(r){
   if(r&&r.ok){toast('Terhubung ke Sheet "'+r.name+'". Mengirim data…');if(!SYNC.linked){Object.keys(DOCS).forEach(function(kk){SYNC.pending[kk]=1;});SYNC.linked=true;}saveSync();syncNow(true);}
   else toast(r&&r.error==='token'?'Kode rahasia tidak cocok dengan TOKEN di skrip.':'Skrip menjawab, tetapi ada kendala.');
  }).catch(function(){toast('Tidak dapat menghubungi skrip. Periksa tautan, akses "Anyone", dan internet.');});}
 else if(a==='sy-now')syncNow(true);
 else if(a==='sy-pull'){SYNC.since=0;saveSync();syncNow(true);}
 else if(a==='sy-off'){SYNC.url='';SYNC.token='';SYNC.linked=false;SYNC.state='idle';saveSync();render();toast('Terputus dari Google Sheets. Data di perangkat tetap aman.');}
 else if(a==='exp-tx'){var L=txs.filter(function(x){return inM(x.date,month)||inM(x.doneDate,month);});
  download('nota-'+month+'.csv','\ufeff'+[['Tgl masuk','Tgl selesai','Tgl diambil','No nota','Pelanggan','No HP','Perangkat','IMEI/SN','Keluhan','Teknisi','Bayar','Status','Total','Modal sparepart','Laba bersih','% bagi hasil','Bagi hasil','% fee','Fee unit','Total teknisi','Sisa toko']].concat(L.map(function(x){var c=calc(x);
   return[x.date,x.doneDate||'',x.pickDate||'',x.no,x.customer,x.phone,x.device,x.imei,x.complaint,techName(x.techId),x.pay,statusOf(x),c.total,c.partCost,c.net,c.share,Math.round(c.bh),c.fee,Math.round(c.feeAmt),Math.round(c.tech),Math.round(c.shop)];})).map(csvRow).join('\n'),'text/csv');}
 else if(a==='exp-exp'){var s2=monthStats(month);download('pengeluaran-'+month+'.csv','\ufeff'+[['Tanggal','Kategori','Keterangan','Jumlah']].concat(s2.E.map(function(e){return[e.date,e.cat,e.note,e.amount];})).map(csvRow).join('\n'),'text/csv');}
 else if(a==='sop-print')window.print();
 else if(a==='sop-setujui'){PREFS.sopSetujui=true;savePrefs();render();toast('SOP telah disetujui.');}}

document.addEventListener('click',function(e){var b=e.target.closest('[data-act]');if(b)act(b.dataset.act,b);});
document.addEventListener('input',function(e){
 var el=e.target,ds=el.dataset;
 if(ds.money!==undefined){
  var val=moneyFix(el);
  if(ds.ed!==undefined){if(editD.items&&editD.items[+ds.i]){editD.items[+ds.i][ds.k]=val;editSums();}}
  else if(ds.i!==undefined&&ds.k!==undefined){draft.items[+ds.i][ds.k]=val;var sm=document.getElementById('sum');if(sm)sm.innerHTML=sumHTML();}
  else if(ds.e)expDraft[ds.e]=val;
  else if(ds.cl)claimD[ds.cl]=val;
  else if(ds.ce)claimEdit[ds.ce]=val;
  else if(ds.c){cfg[ds.c]=val;saveCfg();}
  else if(ds.s){var sp=staff(ds.s);if(sp){sp[ds.f]=val;saveCfg();}}
  return;}
 if(ds.ed!==undefined){if(editD.items&&editD.items[+ds.i]){editD.items[+ds.i][ds.k]=el.value;if(ds.k==='qty')editSums();}}
 else if(ds.k!==undefined&&ds.i!==undefined){draft.items[+ds.i][ds.k]=el.value;var s1=document.getElementById('sum');if(s1)s1.innerHTML=sumHTML();}
 else if(ds.d){draft[ds.d]=el.value;if(ds.d==='techId'){var s2=document.getElementById('sum');if(s2)s2.innerHTML=sumHTML();}else if(ds.d==='lockType')render();}
 else if(ds.e)expDraft[ds.e]=el.value;
 else if(ds.cl)claimD[ds.cl]=el.value;
 else if(ds.ce)claimEdit[ds.ce]=el.value;
 else if(ds.cx)cancelD.reason=el.value;
 else if(ds.ep!==undefined)editD.pin=el.value;
 else if(ds.ap!==undefined)apprD.pin=el.value;
 else if(ds.sy){SYNC[ds.sy]=el.value.trim();saveSync();}});
document.addEventListener('change',function(e){
 var el=e.target,ds=el.dataset;
 if(el.id==='restore-file'){if(el.files&&el.files[0])restoreFile(el.files[0]);el.value='';return;}
 if(ds.money!==undefined)return;
 if(ds.dn){if(el.value){day=el.value;dayAuto=(day===iso(new Date()));openTx=null;render();}}
 else if(ds.m){msgT=el.value;render();}
 else if(ds.d==='customer'){var k=el.value.trim().toLowerCase(),m=custList().find(function(c){return c.name.toLowerCase()===k;});
  if(m&&m.phone&&!draft.phone.trim()){draft.customer=m.name;draft.phone=m.phone;render();toast('Nomor pelanggan lama terisi otomatis.');}}
 else if(ds.p){var pk=ds.p;if(pk==='autoPrint')PREFS.autoPrint=el.value==='1';else if(pk==='pmode')PREFS.pmode=el.value;else PREFS[pk]=+el.value;savePrefs();render();}
 else if(ds.c){var k2=ds.c;
  if(k2==='ownerPin'){var pv=el.value.trim();if(pv){if(!/^\d{4,8}$/.test(pv)){toast('PIN harus 4–8 angka.');el.value='';return;}cfg.ownerPinH=hashPin(pv);toast('PIN Owner disimpan.');}}
  else if(k2==='warrantyDays'||k2==='adminOmzetRate'||k2==='rajinRate')cfg[k2]=Math.max(0,num(el.value));
  else if(k2==='shop')cfg.shop=el.value.trim()||cfg.shop;
  else cfg[k2]=el.value.trim();
  saveCfg();render();toast('Pengaturan tersimpan.');}
 else if(ds.s){var s=staff(ds.s);if(!s)return;var f=ds.f;
  if(f==='name')s.name=el.value.trim()||s.name;
  else if(f==='share'||f==='fee'){if(s.role==='admin')return;s[f]=Math.min(100,Math.max(0,num(el.value)));}
  saveCfg();render();toast('Pengaturan tersimpan.');}});

window.addEventListener('beforeinstallprompt',function(e){e.preventDefault();installEv=e;if(tab==='atur'&&!typing())render();});
window.addEventListener('online',function(){syncNow(false);});
window.addEventListener('offline',function(){SYNC.state='offline';statusRefresh();});
document.addEventListener('visibilitychange',function(){
 if(document.visibilityState!=='visible')return;
 var td=iso(new Date());if(dayAuto&&day!==td){day=td;if(!typing())render();}
 syncNow(false);});
setInterval(function(){if(document.visibilityState==='visible'&&SYNC.url)syncNow(false);},90000);

async function boot(){
 loadPrefs();applyTheme();loadSync();render();
 var rows=[];
 try{IDB=await idbOpen();rows=await idbAll();}
 catch(e){IDB=null;try{var fb=JSON.parse(localStorage.getItem('kp-fallback')||'{}');Object.keys(fb).forEach(function(k){rows.push({k:k,v:fb[k]});});}catch(x){}}
 rows.forEach(function(r){DOCS[r.k]=r.v;});
 rebuild();
 var c0=DOCS['cfg/main'];
 if(c0&&(c0.staff||[]).some(function(s){return s.role!=='admin'&&(+s.base||0)>0;}))saveCfg();
 render();
 if(SYNC.url)syncNow(false);
 try{if(document.fonts&&document.fonts.load){await Promise.all([document.fonts.load('800 26px Archivo'),document.fonts.load('700 15px "IBM Plex Sans"'),document.fonts.load('500 14px "IBM Plex Sans"'),document.fonts.load('700 24px "IBM Plex Mono"'),document.fonts.load('500 14px "IBM Plex Mono"')]);imgCache={key:'',url:''};if(!typing())render();}}catch(e){}
}
try{if('serviceWorker' in navigator&&location.protocol.indexOf('http')===0)navigator.serviceWorker.register('sw.js').catch(function(){});}catch(e){}
boot();
})();
</script>
</body>
</html>